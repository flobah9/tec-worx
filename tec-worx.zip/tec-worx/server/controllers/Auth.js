const Employees = require("../models/Employee");
const bcrypt = require('bcrypt');
const saltRounds = 10;

const Login = async (req, res) => {
    const user = await Employees.findOne({
        where: {
            userName: req.body.userName
        }
    });
    if (!user) return res.status(404).json({ msg: "User not found" });
    const match = await bcrypt.compare(req.body.password, user.password);
    if (!match) return res.status(400).json({ msg: "Wrong Password" });
    req.session.userId = user.uuid;
    const uuid = user.uuid;
    const firstName = user.firstName;
    const lastName = user.lastName;
    const phone = user.phone;
    const address = user.address;
    const email = user.email;
    const userName = user.userName;
    const role = user.role;
    res.status(200).json({ uuid, firstName, lastName, phone, address, userName, email, role });
}

const Me = async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ msg: "Please login to your account!" });
    }
    const user = await Employees.findOne({
        attributes: ['uuid', 'firstName', 'lastName', 'phone', 'address', 'userName', 'email', 'role'],
        where: {
            uuid: req.session.userId
        }
    });
    if (!user) return res.status(404).json({ msg: "User not found" });
    res.status(200).json(user);
}

const logOut = (req, res) => {
    req.session.destroy((err) => {
        if (err) return res.status(400).json({ msg: "Can not logout" });
        res.status(200).json({ msg: "You have logout" });
    });
}

const changePassword = async (req, res) => {
    try {
        const { current, newpass, confirmNew } = req.body;
        const user = await Employees.findOne({
            where: {
                id: req.userId
            }
        });
        if (!user) return res.status(404).json({ msg: "User not found" });
        else {
            const match = await bcrypt.compare(req.body.password, user.password);
            if (!match) return res.status(400).json({ msg: "Current password entered is wrong" });
            else {
                if (newpass !== confirmNew) return res.status(400).json({ msg: "Password entered don`t match" });
                else {
                    const hashPassword = await bcrypt.hash(newpass, saltRounds);
                    await Employees.update({
                        password: hashPassword
                    }, {
                        where: {
                            id: req.userId
                        }
                    });
                    res.status(200).json({ msg: "User successfully changed password" });
                }
            }
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

module.exports = {
    Login,
    Me,
    logOut,
    changePassword
}