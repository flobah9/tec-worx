const Payments = require ("../models/Cardpayment");
const Sales = require ("../models/Sales");
const JobCards = require ("../models/JobCard");
const SoldItems = require ('../models/SoldItems');
const Requirements = require ('../models/Requirements');
const WorkCards = require ("../models/WorkCard");
const Stock = require ("../models/Inventory");
const DiagnosisFee = require ("../models/DiagnosisFee");
const sequelize = require ("sequelize");
const { Op } = require ("sequelize");
const Customer = require ("../models/Customer");

const PayForCard = async (req, res) => {
    const items = req.body || [];
    const status = "Repair";
    try {
        const response = await JobCards.findOne({
            attributes: ['id', 'cardNo', 'status'],
            where: {
                cardNo: items.cardNo
            },
            include: [{
                model: WorkCards,
                attributes: ['labourCharge', 'id'],
                include: [{
                    model: Requirements,
                    attributes: ['workcard_id', 'keepingUnit', 'product', 'price', 'isToBePaid', 'isPaidFor']
                }]
            }]
        });
        if (!response) return res.status(500).json({ msg: "Jobcard not found" });
        else {
            const data = await Payments.create({
                cardNo: items.cardNo,
                totalAmount: items.totalAmount,
                paidAmount: items.paidAmount,
                user: req.userId
            });
            if (!data) return res.status(404).json({ msg: "Something went wrong" });
            else {
                if (!(response.status === status || response.status === "Complete")) {
                    await JobCards.update({
                        status: status
                    }, {
                        where: {
                            id: response.id
                        }
                    });
                }
                if (items?.products != null) {
                    if (items.totalAmount === items.paidAmount || items.paidAmount >= items.totalAmount) {
                        let newTotal = parseFloat(items.totalAmount).toFixed(2) - parseFloat(response.workshop.labourCharge).toFixed(2)
                        const totalSum = parseFloat(newTotal).toFixed(2)
                        const sales = await Sales.create({
                            totalAmount: totalSum,
                            method: items.method,
                            rate: items.rate,
                            newTotalAmount: totalSum,
                            paidAmount: items.paidAmount,
                            phone: items.phone,
                            cashier: req.userId
                        });
                        if (sales) {
                            await Payments.update({
                                sales_id: sales.id
                            }, {
                                where: {
                                    id: data.id
                                }
                            });
                            items?.products?.forEach(async (element) => {
                                await SoldItems.create({
                                    sales_id: sales.id,
                                    product: element.product,
                                    keepingUnit: element.keepingUnit,
                                    price: element.price,
                                    quantity: 1,
                                    cost: element.totalAmount
                                });
                                const item = await Stock.findOne({
                                    where: {
                                        keepingUnit: element.keepingUnit
                                    }
                                });
                                if (item) {
                                    const qty = parseInt(item.quantity) - parseInt(1)
                                    await Stock.update({
                                        quantity: qty
                                    }, {
                                        where: {
                                            id: item.id
                                        }
                                    });
                                }
                                await Requirements.update({
                                    isPaidFor: 1
                                }, {
                                    where: {
                                        [Op.and]: [
                                            { workcard_id: response.workshop?.requirements?.map(x => x.workcard_id) },
                                            { keepingUnit: element.keepingUnit }
                                        ]
                                    }
                                });
                            });
                        }
                    }
                    else {
                        items?.products?.forEach(async (element) => {
                            await Requirements.update({
                                isToBePaid: 1
                            }, {
                                where: {
                                    [Op.and]: [
                                        { workcard_id: response.workshop?.requirements?.map(x => x.workcard_id) },
                                        { keepingUnit: element.keepingUnit }
                                    ]
                                }
                            });
                        });
                    }
                }
                res.status(200).json({ msg: "Transaction is completed" })
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const PayDiagnosisFee = async (req, res) => {
    const { cardNo, amount, method, rate, finalAmount } = req.body;
    const status = "Ready";
    try {
        const response = await JobCards.findOne({
            where: {
                cardNo: cardNo
            }
        });
        if (!response) return res.status(500).json({ msg: "Jobcard not found" });
        else {
            const data = await DiagnosisFee.findOne({
                where: {
                    cardNo: response.cardNo
                }
            });
            if (data) return res.status(500).json({ msg: "Already paid diagnosis fee" });
            else {
                const record = await DiagnosisFee.create({
                    cardNo: response.cardNo,
                    amount: amount,
                    method: method,
                    rate: rate,
                    finalAmount: finalAmount,
                    user: req.userId
                });
                if (record) {
                    await JobCards.update({
                        status: status
                    }, {
                        where: {
                            id: response.id
                        }
                    });
                    res.status(200).json({ msg: "Transaction is completed" })
                } else {
                    return res.status(500).json({ msg: "Something went wrong" });
                }
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindJobCardPayment = async (req, res) => {
    try {
        const response = await Payments.findAll({
            attributes: ['id', 'date', 'totalAmount', 'cardNo',
                [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
            group: ['cardNo'],
            raw: true,
            where: {
                cardNo: req.params.cardNo
            },
            include: [{
                model: JobCards,
                attributes: ['id', 'customerID', 'status', 'model'],
            }]
        });
        if (!response) return res.status(404).json({ msg: "" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const UpdatePayForCard = async (req, res) => {
    try {
        const { amount, cardNo, method, rate, phone } = req.body;
        const response = await Payments.findAll({
            attributes: [
                'cardNo', 'totalAmount', 'id',
                [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum'],
            ],
            group: ['cardNo'],
            raw: true,
            where: {
                cardNo: cardNo,
            }
        });
        if (!response) return res.status(404).json({ msg: "Something went wrong" });
        else {
            const paid = response.map(x => x.paidSum)
            const totalAmount = response.map(x => x.totalAmount)
            const current = await Payments.create({
                cardNo: cardNo,
                paidAmount: amount,
                totalAmount: totalAmount,
                user: req.userId
            });
            if (!current) return res.status(404).json({ msg: "Something went wrong" });
            else {
                const newPaid = parseFloat(paid) + parseFloat(amount)
                if (parseFloat(newPaid).toFixed(2) >= parseFloat(totalAmount).toFixed(2)) {
                    const data = await WorkCards.findOne({
                        attributes: ['id', 'labourCharge'],
                        where: {
                            cardNo: cardNo
                        }
                    });
                    if (!data) return res.status(404).json({ msg: "Something went wrong" });
                    else {
                        const items = await Requirements.findAll({
                            attributes: [
                                'workcard_id', 'keepingUnit', 'product', 'id', 'price'
                            ],
                            group: ['id'],
                            raw: true,
                            where: {
                                [Op.and]: [
                                    { workcard_id: data.id },
                                    { isToBePaid: 1 }
                                ]

                            }
                        });
                        if (!items) return res.status(404).json({ msg: "Something went wrong" });
                        else {
                            const value = eval(items.map(x => x.price).join('+'))
                            const sum = parseFloat(value) * parseFloat(rate)
                            const finalAmount = parseFloat(sum).toFixed(2)
                            const paying = parseFloat(newPaid) * parseFloat(rate)
                            const paidAmount = parseFloat(paying).toFixed(2)
                            const sales = await Sales.create({
                                totalAmount: parseFloat(value).toFixed(2),
                                method: method,
                                rate: rate,
                                newTotalAmount: finalAmount,
                                paidAmount: paidAmount,
                                phone: phone,
                                cashier: req.userId
                            });
                            if (sales) {
                                await Payments.update({
                                    sales_id: sales.id
                                }, {
                                    where: {
                                        id: current.id
                                    }
                                });
                                items?.forEach(async (element) => {
                                    const totalItemCost = parseFloat(element.price) * parseInt(1)
                                    await SoldItems.create({
                                        sales_id: sales.id,
                                        product: element.product,
                                        keepingUnit: element.keepingUnit,
                                        price: element.price,
                                        quantity: 1,
                                        cost: totalItemCost
                                    });
                                    const item = await Stock.findOne({
                                        where: {
                                            keepingUnit: element.keepingUnit
                                        }
                                    });
                                    if (item) {
                                        const qty = parseInt(item.quantity) - parseInt(1)
                                        await Stock.update({
                                            quantity: qty
                                        }, {
                                            where: {
                                                id: item.id
                                            }
                                        });
                                        await Requirements.update({
                                            isPaidFor: 1
                                        }, {
                                            where: {
                                                [Op.and]: [
                                                    { workcard_id: data.id },
                                                    { keepingUnit: element.keepingUnit }
                                                ]
                                            }
                                        });
                                    }
                                })
                            }
                        }
                    }
                }
                res.status(200).json({ msg: "Transaction is completed" })
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindCustomerCardPayments = async (req, res) => {
    try {
        const customer = await Customer.findOne({
            attributes: ['id', 'customerID'],
            where: {
                id: req.customerId
            }
        });
        if (customer) {
            const response = await JobCards.findAll({
                where: {
                    customerID: customer.customerID
                }
            });
            var value = []
            if (!response) return res.status(404).json({ msg: "No card found" });
            else {
                for (let index = 0; index < response.length; index++) {
                    const element = await Payments.findAll({
                        attributes: ['id', 'cardNo', 'totalAmount', 'date', 'paidAmount'],
                        order: [['cardNo', 'ASC']],
                        raw: true,
                        where: {
                            cardNo: response[index].cardNo
                        }
                    })
                    value.push(element)
                }
                res.status(200).json(value);
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindCustomerSalesPayments = async (req, res) => {
    try {
        const customer = await Customer.findOne({
            order: [['id', 'DESC']],
            attributes: ['id', 'customerID', 'phone'],
            where: {
                id: req.customerId
            }
        });
        if (customer) {
            const response = await Sales.findAll({
                attributes: ['id', 'totalAmount', 'paidAmount', 'method', 'date'],
                where: {
                    phone: customer.phone
                },
                include: [{
                    model: SoldItems,
                    attributes: ['id', 'product', 'price', 'quantity']
                }]
            });
            if (!response) return res.status(404).json({ msg: "No card found" });
            else {
                res.status(200).json(response);
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindAllCardPayments = async (req, res) => {
    try {
        const response = await JobCards.findAll();
        var value = []
        if (!response) return res.status(404).json({ msg: "No card found" });
        else {
            for (let index = 0; index < response.length; index++) {
                const element = await Payments.findAll({
                    attributes: ['id', 'cardNo', 'totalAmount', 'date',
                        [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
                    //order: [['cardNo', 'ASC']],
                    group: ['cardNo'],
                    raw: true,
                    where: {
                        cardNo: response[index].cardNo
                    }
                })
                value.push(element)
            }
            res.status(200).json(value);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    PayForCard,
    FindAllCardPayments,
    FindCustomerCardPayments,
    FindCustomerSalesPayments,
    FindJobCardPayment,
    UpdatePayForCard
}