const Category = require("../models/Category");

const getCategory = async (req, res) => {
    try {
        const response = await Category.findAll({
            attributes: ['id', 'uuid', 'category', 'description']
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getCategoryById = async (req, res) => {
    try {
        const response = await Category.findOne({
            attributes: ['id', 'uuid', 'category', 'description'],
            where: {
                id: req.params.id
            }
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewCategory = async (req, res) => {
    const { category, description } = req.body;
    const cat = await Category.findOne({
        where: {
            category: category
        }
    });
    if (cat) return res.status(404).json({ msg: "Category name already exist" });
    else {
        try {
            await Category.create({
                category: category,
                description: description
            });
            res.status(201).json({ msg: "Category successfully created" });
        } catch (error) {
            res.status(400).json({ msg: error.message });
        }
    }
}

const updateCategory = async (req, res) => {
    const cat = await Category.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!cat) return res.status(404).json({ msg: "Category not found" });
    const { category, description } = req.body;
    try {
        await Category.update({
            category: category,
            description: description
        }, {
            where: {
                id: cat.id
            }
        });
        res.status(201).json({ msg: "Successfully updated" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const deleteCategory = async (req, res) => {
    const cat = await Category.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!cat) return res.status(404).json({ msg: "Category not found" });
    try {
        await Category.destroy({
            where: {
                id: cat.id
            }
        });
        res.status(200).json({ msg: "Category deleted" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const countCategory = async (req, res) => {
    try {
        const { count } = await Category.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

module.exports = {
    deleteCategory,
    countCategory,
    addNewCategory,
    updateCategory,
    getCategory,
    getCategoryById
}