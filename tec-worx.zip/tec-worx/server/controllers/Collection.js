const Collection = require("../models/CollectionForm");
const JobCards = require("../models/JobCard");
const Payments = require("../models/Cardpayment");
const sequelize = require("sequelize");

const AddCollectionForm = async (req, res) => {
    const { customerID, cardNo, collectedBy, fullName, phone, isCollected } = req.body;
    try {
        const response = await JobCards.findOne({
            where: {
                id: req.body.id
            }
        })
        if (!response) return res.status(404).json({ msg: "Job card not found" });
        else {
            if (response.status === "Cancelled") {
                const data = await Collection.create({
                    customerID: customerID,
                    cardNo: cardNo,
                    collectedBy: collectedBy,
                    fullName: fullName,
                    phone: phone,
                    user: req.userId
                });
                if (!data) return res.status(404).json({ msg: "Failed to capture data therefore jobcard can not be collected" });
                else {
                    await JobCards.update({
                        isCollected: isCollected
                    },
                        {
                            where: {
                                id: response.id
                            }
                        });
                    res.status(201).json({ msg: "Device collected successfully" });
                }
            }
            else if (response.status === "Complete") {
                const payment = await Payments.findAll({
                    attributes: ['id', 'cardNo', 'totalAmount',
                        [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
                    group: ['cardNo'],
                    raw: true,
                    where: {
                        cardNo: cardNo
                    }
                });
                if (payment.map(x => x.paidSum) >= payment.map(x => x.totalAmount)) {
                    const completed = await Collection.create({
                        customerID: customerID,
                        cardNo: cardNo,
                        collectedBy: collectedBy,
                        fullName: fullName,
                        phone: phone,
                        user: req.userId
                    });
                    if (!completed) return res.status(404).json({ msg: "Failed to capture data therefore jobcard can not be collected" });
                    else {
                        await JobCards.update({
                            isCollected: isCollected
                        },
                            {
                                where: {
                                    id: response.id
                                }
                            });
                        res.status(201).json({ msg: "Device collected successfully" });
                    }
                } else {
                    res.status(404).json({ msg: "Please clear the outstanding balance" });
                }
            }
            else {
                res.status(404).json({ msg: "Device can not be collected at this stage" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = { AddCollectionForm }