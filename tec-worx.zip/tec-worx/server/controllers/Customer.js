const Customer = require("../models/Customer");

const getAllCustomers = async (req, res) => {
    try {
        const response = await Customer.findAll({
            attributes: ['id', 'fullName', 'customerID', 'phone', 'email', 'address', 'contactPerson', 'contactPersonCell', 'role']
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getCustomerByCustomerID = async (req, res) => {
    try {
        const { customerID } = req.body;
        const response = await Customer.findOne({
            attributes: ['id', 'fullName', 'phone'],
            where: {
                customerID: customerID
            }
        });
        if (response) return res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewCustomer = async (req, res) => {
    if (req.role === 'Technician') {
        return res.status(404).json({ msg: "Access denied" });
    }
    else {
        const { fullName, phone, email, address, contactPerson, contactPersonCell, role } = req.body;
        const user = await Customer.findOne({
            where: {
                phone: phone,
                email: email
            }
        });
        if (user) return res.status(404).json({ msg: "Phone number already used" });
        else {
            try {
                await Customer.create({
                    fullName: fullName,
                    address: address,
                    phone: phone,
                    email: email,
                    contactPerson: contactPerson,
                    contactPersonCell: contactPersonCell,
                    role: role
                });
                res.status(201).json({ msg: "Registration was a success" });
            } catch (error) {
                res.status(400).json({ msg: error.message });
            }
        }
    }
}

const updateCustomer = async (req, res) => {
    if (req.role === 'Technician') {
        return res.status(404).json({ msg: "Access denied" });
    }
    else {
        const user = await Customer.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!user) return res.status(404).json({ msg: "User not found" });
        const { fullName, phone, email, address, contactPerson, contactPersonCell, role } = req.body;
        try {
            await Customer.update({
                fullName: fullName,
                address: address,
                phone: phone,
                email: email,
                contactPerson: contactPerson,
                contactPersonCell: contactPersonCell,
                role: role
            }, {
                where: {
                    id: user.id
                }
            });
            res.status(201).json({ msg: "Successfully updated" });
        } catch (error) {
            res.status(400).json({ msg: error.message });
        }
    }
}

const deleteCustomer = async (req, res) => {
    if (req.role === 'Technician') {
        return res.status(404).json({ msg: "Access denied" });
    }
    else {
        const user = await Customer.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!user) return res.status(404).json({ msg: "User not found" });
        try {
            await Customer.destroy({
                where: {
                    id: user.id
                }
            });
            res.status(200).json({ msg: "User Deleted" });
        } catch (error) {
            res.status(400).json({ msg: error.message });
        }
    }
}

const searchPhone = async (req, res) => {
    try {
        const response = await Customer.findOne({
            attributes: ['id', 'fullName', 'customerID', 'phone', 'email', 'address', 'contactPerson', 'contactPersonCell', 'role'],
            where: {
                phone: req.params.phone
            }
        });
        if (!response) {
            res.status(404).json({ msg: "Phone not found" });
        }
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const countCustomers = async (req, res) => {
    try {
        const { count } = await Customer.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

module.exports = {
    addNewCustomer,
    updateCustomer,
    deleteCustomer,
    searchPhone,
    countCustomers,
    getAllCustomers,
    getCustomerByCustomerID
}



