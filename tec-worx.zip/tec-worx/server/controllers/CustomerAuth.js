const Customer = require("../models/Customer");

const Login = async (req, res) => {
    try {
        const user = await Customer.findOne({
            where: {
                fullName: req.body.fullName
            }
        });
        if (!user) return res.status(404).json({ msg: "User not found" });
        else {
            if (user.phone !== req.body.phone) return res.status(400).json({ msg: "Phone not corresponding to user" });
            req.session.customerId = user.uuid;
            const uuid = user.uuid;
            const fullName = user.fullName;
            const customerID = user.customerID;
            const phone = user.phone;
            const address = user.address;
            const email = user.email;
            const contactPerson = user.contactPerson;
            const contactPersonCell = user.contactPersonCell;
            const role = user.role;
            res.status(200).json({ uuid, fullName, customerID, phone, address, email, contactPerson, contactPersonCell, role });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const logOut = (req, res) => {
    req.session.destroy((err) => {
        if (err) return res.status(400).json({ msg: "Can not logout" });
        res.status(200).json({ msg: "You have logout" });
    });
}

module.exports = {
    Login,
    logOut
}