const Customer = require("../models/Customer");
const JobCard = require("../models/JobCard");
const WorkCards = require("../models/WorkCard");
const Manufacturer = require("../models/orderService/Manufacturer");
const RepairCategory = require("../models/orderService/RepairCategory");
const Requirements = require("../models/Requirements");

const CustomerRegistration = async (req, res) => {
    try {
        const { fullName, phone, email, address, contactPerson, contactPersonCell, role } = req.body;
        const user = await Customer.findOne({
            where: {
                phone: phone
            }
        });
        if (user) return res.status(404).json({ msg: "Email || Phone number already used" });
        else {
            await Customer.create({
                fullName: fullName,
                address: address,
                phone: phone,
                email: email,
                contactPerson: contactPerson,
                contactPersonCell: contactPersonCell,
                role: role
            });
            res.status(201).json({ msg: "Registration was a success" });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const GetAllJobCards = async (req, res) => {
    try {
        const user = await Customer.findOne({
            where: {
                id: req.customerId
            }
        });
        if (user) {
            const response = await JobCard.findAll({
                attributes: ['cardNo', 'date', 'model', 'serialNo', 'problemDesc', 'comments', 'image', 'status'],
                where: {
                    customerID: user.customerID
                },
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }, {
                    model: WorkCards,
                    attributes: ['id', 'date', 'diagnosisResults', 'otherRequirements', 'labourCharge', 'jobdone', 'partsUsed', 'timeTaken', 'invoice'],
                    include: [{
                        model: Requirements,
                        attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
                    }]
                }]
            });
            if (response) res.status(200).json(response);
            else {
                res.status(404).json({ msg: "Error on retrieving data" });
            }
        }
        else {
            res.status(404).json({ msg: "User not found" });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const CountMyJobCards = async (req, res) => {
    try {
        const user = await Customer.findOne({
            where: {
                id: req.customerId
            }
        });
        if (user) {
            const { count } = await JobCard.findAndCountAll({
                where: {
                    customerID: user.customerID
                }
            });
            res.status(200).json(count);
        }
        else {
            res.status(404).json({ msg: "User not found" });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const GetCustomerProfile = async (req, res) => {
    try {
        const user = await Customer.findOne({
            attributes: ['id', 'fullName', 'customerID', 'phone', 'email', 'address', 'contactPerson', 'contactPersonCell', 'role'],
            where: {
                id: req.customerId
            }
        });
        if (user) {
            res.status(200).json(user);
        } else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

module.exports = {
    CustomerRegistration,
    GetAllJobCards,
    CountMyJobCards,
    GetCustomerProfile
}