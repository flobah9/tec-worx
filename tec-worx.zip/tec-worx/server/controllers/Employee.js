const Employees = require("../models/Employee");
const bcrypt = require('bcrypt');
const saltRounds = 10;
const { Op } = require("sequelize");

const getAllEmployees = async (req, res) => {
    try {
        const response = await Employees.findAll({
            attributes: ['uuid', 'id', 'firstName', 'lastName', 'userName', 'phone', 'email', 'address', 'role']
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getEmployeeById = async (req, res) => {
    try {
        const response = await Employees.findOne({
            attributes: ['uuid', 'id', 'firstName', 'lastName', 'userName', 'phone', 'email', 'address', 'role'],
            where: {
                id: req.params.id
            }
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewEmployee = async (req, res) => {
    const { firstName, lastName, phone, address, email, role } = req.body;
    const user = await Employees.findOne({
        where: {
            email: email
        }
    });
    if (user) return res.status(404).json({ msg: "Email already used" });
    else {
        try {
            await Employees.create({
                firstName: firstName,
                lastName: lastName,
                phone: phone,
                address: address,
                email: email,
                role: role
            });
            res.status(201).json({ msg: "Registration was a success" });
        } catch (error) {
            res.status(400).json({ msg: error.message });
        }
    }
}

const updateEmployee = async (req, res) => {
    const user = await Employees.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!user) return res.status(404).json({ msg: "User not found" });
    const { firstName, lastName, phone, address, email, role } = req.body;
    try {
        await Employees.update({
            firstName: firstName,
            lastName: lastName,
            phone: phone,
            address: address,
            email: email,
            role: role
        }, {
            where: {
                id: user.id
            }
        });
        res.status(201).json({ msg: "Successfully updated" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const deleteEmployee = async (req, res) => {
    const user = await Employees.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!user) return res.status(404).json({ msg: "User not found" });
    try {
        await Employees.destroy({
            where: {
                id: user.id
            }
        });
        res.status(200).json({ msg: "User Deleted" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const signUpEmployee = async (req, res) => {
    const { email, userName, password, confirmPass } = req.body;
    if (password !== confirmPass)
        return res.status(400).json({ msg: "Password entered don`t match" });
    else {
        const user = await Employees.findOne({
            where: {
                email: email
            }
        });
        if (!user) return res.status(404).json({ msg: "Email not found" });
        else {
            const name = user.userName;
            const hashPassword = await bcrypt.hash(password, saltRounds);
            if (name === "" || name === null) {
                try {
                    await Employees.update({
                        userName: userName,
                        password: hashPassword
                    }, {
                        where: {
                            id: user.id
                        }
                    });
                    res.status(200).json({ msg: "User successfully signed up" });
                } catch (error) {
                    res.status(400).json({ msg: error.message });
                }
            }
            else {
                res.status(404).json({ msg: "User already signed up" });
            }
        }
    }
}

const countEmployee = async (req, res) => {
    try {
        const { count } = await Employees.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

const getAllTechnicians = async (req, res) => {
    try {
        const response = await Employees.findAll({
            attributes: ['id', 'firstName', 'lastName'],
            where: {
                [Op.or]: [
                    { role: { [Op.like]: 'Tech%' } }
                ]
            }
        });
        if (response) return res.status(200).json(response);
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

module.exports = {
    getAllEmployees,
    getAllTechnicians,
    addNewEmployee,
    signUpEmployee,
    updateEmployee,
    countEmployee,
    deleteEmployee,
    getAllEmployees,
    getEmployeeById
}



