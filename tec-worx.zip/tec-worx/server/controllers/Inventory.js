const Stock = require("../models/Inventory");
const Make = require("../models/Make");
const Category = require("../models/Category");
const { Op } = require('sequelize')

const getAllProducts = async (req, res) => {
    try {
        const response = await Stock.findAll({
            attributes: ['uuid', 'id', 'product', 'catId', 'makeId', 'description', 'keepingUnit', 'price', 'quantity'],
            include: [{
                model: Make,
                attributes: ['make'],
                include: [{
                    model: Category,
                    attributes: ['category']
                }]
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getProductById = async (req, res) => {
    try {
        const response = await Stock.findOne({
            attributes: ['uuid', 'id', 'makeId', 'product', 'description', 'keepingUnit', 'price', 'quantity'],
            where: {
                id: req.params.id
            },
            include: [{
                model: Make,
                attributes: ['make'],
                include: [{
                    model: Category,
                    attributes: ['category']
                }]
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    }
    catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getProductBySKU = async (req, res) => {
    try {
        const response = await Stock.findOne({
            attributes: ['id', 'product', 'price', 'quantity', 'keepingUnit'],
            where: {
                keepingUnit: req.params.keepingUnit
            },
            include: [{
                model: Make,
                attributes: ['make'],
                include: [{
                    model: Category,
                    attributes: ['category']
                }]
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    }
    catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewProduct = async (req, res) => {
    const { catId, makeId, product, description, price, quantity } = req.body;
    const stock = await Stock.findOne({
        where: {
            product: product
        }
    });
    if (stock) return res.status(404).json({ msg: "Product name already exist" });
    else {
        try {
            await Stock.create({
                catId: catId,
                makeId: makeId,
                product: product,
                description: description,
                price: price,
                quantity: quantity
            });
            res.status(201).json({ msg: "New item in stock added" });
        } catch (error) {
            res.status(400).json({ msg: error.message });
        }
    }
}

const updateProduct = async (req, res) => {
    const stock = await Stock.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!stock) return res.status(404).json({ msg: "Product not found" });
    const { catId, makeId, product, description, price, quantity } = req.body;;
    try {
        await Stock.update({
            catId: catId,
            makeId: makeId,
            product: product,
            description: description,
            price: price,
            quantity: quantity
        }, {
            where: {
                id: stock.id
            }
        });
        res.status(201).json({ msg: "Successfully updated" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const deleteProduct = async (req, res) => {
    const prod = await Stock.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!prod) return res.status(404).json({ msg: "Product not found" });
    try {
        await Stock.destroy({
            where: {
                id: prod.id
            }
        });
        res.status(200).json({ msg: "Product deleted" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const countProducts = async (req, res) => {
    try {
        const { count } = await Stock.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

const GetLowStockItems = async (req, res) => {
    try {
        const qty = "5";
        const response = await Stock.findAll({
            attributes: ['id', 'keepingUnit', 'price', 'quantity'],
            where: {
                [Op.lte]: [{ quantity: qty }]
            }
        })
        if (!response) return res.status(404).json({ msg: "No low stock items" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(400).json({ msg: error.message })
    }
}

module.exports = {
    addNewProduct,
    updateProduct,
    deleteProduct,
    countProducts,
    GetLowStockItems,
    getAllProducts,
    getProductById,
    getProductBySKU
}

