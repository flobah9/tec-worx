const JobCard = require("../models/JobCard");
const RepairCategory = require("../models/orderService/RepairCategory");
const Manufacturer = require("../models/orderService/Manufacturer");
const Customer = require("../models/Customer");
const WorkCards = require("../models/WorkCard");
const Employees = require("../models/Employee");
const dotenv = require("dotenv");
const { Op } = require("sequelize");
const sgMail = require('@sendgrid/mail')
const Requirements = require("../models/Requirements");

dotenv.config();

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

async function getAllJobCards(req, res) {
    try {
        const response = await JobCard.findAll({
            order: [['id', 'DESC']],
            attributes: ['id', 'cardNo', 'date', 'catId', 'makeId', 'customerID', 'model', 'serialNo', 'problemDesc', 'comments', 'image', 'status', 'isCollected'],
            include: [{
                model: Manufacturer,
                attributes: ['manufacture'],
                include: [{
                    model: RepairCategory,
                    attributes: ['repair']
                }]
            },
            {
                model: Customer,
                attributes: ['fullName', 'phone', 'email']
            }, {
                model: WorkCards,
                attributes: ['id', 'date', 'diagnosisResults', 'estimatedTime', 'labourCharge', 'jobdone', 'partsUsed', 'timeTaken', 'technician'],
                include: [{
                    model: Employees,
                    attributes: ['firstName', 'lastName']
                }, {
                    model: Requirements,
                    attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
                }]
            }],
        });
        if (response)
            res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function getJobCardByCardNo(req, res) {
    try {
        const response = await JobCard.findOne({
            attributes: ['id', 'customerID', 'status', 'model'],
            where: {
                cardNo: req.params.cardNo
            },
            include: [{
                model: Customer,
                attributes: ['fullName', 'phone', 'email']
            }, {
                model: WorkCards,
                attributes: ['labourCharge'],
                include: [{
                    model: Requirements,
                    attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
                }]
            }]
        });
        if (response) return res.status(200).json(response);
        res.status(404).json({ msg: "Error on retrieving data" });
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function getJobCardByCustomerID(req, res) {
    const { customerID } = req.body;
    try {
        const response = await Customer.findAll({
            where: {
                customerID: customerID
            }
        });
        if (!response)
            return res.status(404).json({ msg: "User not found" });
        else {
            const details = await JobCard.findAll({
                attributes: ['cardNo', 'date', 'catId', 'makeId', 'model', 'serialNo', 'problemDesc', 'comments', 'image', 'status'],
                where: {
                    customerID: response.customerID
                },
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            });
            if (details)
                res.status(200).json(details);
            else {
                res.status(404).json({ msg: "No jobcard for customer" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function getAllJobCardsToDiagnose(req, res) {
    try {
        const status = null;
        const response = await JobCard.findAll({
            attributes: ['id', 'cardNo', 'date', 'catId', 'makeId', 'model', 'serialNo', 'problemDesc', 'comments', 'image'],
            where: {
                status: status
            },
            include: [{
                model: Manufacturer,
                attributes: ['manufacture'],
                include: [{
                    model: RepairCategory,
                    attributes: ['repair']
                }]
            }]
        });
        if (response)
            res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function addNewJobCard(req, res) {
    const { customerID, date, catId, makeId, model, serialNo, problemDesc, comments, status } = req.body;
    try {
        const response = await Customer.findOne({
            where: {
                customerID: customerID
            }
        });
        if (!response)
            return res.status(404).json({ msg: "User not found" });
        else {
            await JobCard.create({
                customerID: customerID,
                date: date,
                catId: catId,
                makeId: makeId,
                model: model,
                serialNo: serialNo,
                problemDesc: problemDesc,
                comments: comments,
                image: req.file?.path.replace(/\\/g, '/'),
                status: status
            });
            const data = await Employees.findAll({
                attributes: ['email', 'id'],
                where: {
                    [Op.or]: [
                        { role: { [Op.like]: 'Tech%' } }
                    ]
                }
            });
            if (!data)
                return res.status(404).json({ msg: "User not found" });
            else {
                data.forEach((element) => {
                    const message = {
                        from: 'manflobah9@gmail.com',
                        to: `${element.email}`,
                        subject: 'Alert!!! new jobcard',
                        text: 'Good day kindly note that there is a new entry of a job card',
                    };
                    sgMail
                        .send(message)
                        .then(() => {
                            console.log('Email sent')
                        })
                        .catch((error) => {
                            console.error(error)
                        })
                });
            }
            res.status(201).json({ msg: "Job card successfully created" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function RecordMyJobCard(req, res) {
    const { date, repairId, manufactId, model, serialNo, problemDesc } = req.body;
    try {
        const response = await Customer.findOne({
            where: {
                id: req.customerId
            }
        });
        if (!response)
            return res.status(404).json({ msg: "User not found" });
        else {
            const data = await JobCard.findOne({
                where: {
                    date: date
                }
            });
            if (data)
                return res.status(404).json({ msg: "Time is occupied try choose either different day or time" });
            else {
                await JobCard.create({
                    customerID: response.customerID,
                    date: date,
                    catId: repairId,
                    makeId: manufactId,
                    model: model,
                    serialNo: serialNo,
                    problemDesc: problemDesc,
                });
                const user = await Employees.findAll({
                    attributes: ['email', 'id'],
                    where: {
                        [Op.or]: [
                            { role: { [Op.like]: 'User%' } }
                        ]
                    }
                });
                if (!user)
                    return res.status(404).json({ msg: "User not found" });
                else {
                    user.forEach((element) => {
                        const message = {
                            from: 'manflobah9@gmail.com',
                            to: `${element.email}`,
                            subject: 'Alert!!! new jobcard',
                            text: 'Good day kindly note that there is a new entry of a job card that have been booked',
                        };
                        sgMail
                            .send(message)
                            .then(() => {
                                console.log('Email sent')
                            })
                            .catch((error) => {
                                console.error(error)
                            })
                    });
                }
                res.status(201).json({ msg: "Job card successfully created" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function updateJobCard(req, res) {
    const { comments, model, serialNo, problemDesc } = req.body;
    try {
        const response = await JobCard.findOne({
            where: {
                id: req.body.id
            }
        });
        if (!response)
            return res.status(404).json({ msg: "Card not found" });
        else {
            await JobCard.update({
                comments: comments,
                model: model,
                serialNo: serialNo,
                problemDesc: problemDesc,
                image: req.file?.path.replace(/\\/g, '/'),
            }, {
                where: {
                    id: response.id
                }
            });
            res.status(201).json({ msg: "Job card successfully updated" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function countJobCards(req, res) {
    try {
        const { count } = await JobCard.findAndCountAll();
        res.status(200).json(count);
    } catch (error) {
        console.log(error);
    }
}

async function countJobCardsDiagonised(req, res) {
    try {
        const status = null;
        const { count } = await JobCard.findAndCountAll({
            where: {
                status: status
            }
        });
        res.status(200).json(count);
    } catch (error) {
        console.log(error);
    }
}

async function countJobCardsCancelled(req, res) {
    try {
        const status = "Cancelled";
        const { count } = await JobCard.findAndCountAll({
            where: {
                status: status
            }
        });
        res.status(200).json(count);
    } catch (error) {
        console.log(error);
    }
}

async function countJobCardsRepair(req, res) {
    try {
        const status = "Repair";
        const { count } = await JobCard.findAndCountAll({
            where: {
                status: status
            }
        });
        res.status(200).json(count);
    } catch (error) {
        console.log(error);
    }
}

async function CancelJobCard(req, res) {
    try {
        const status = "Cancelled";
        const response = await JobCard.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!response)
            return res.status(404).json({ msg: "Jobcard not found" });
        else {
            await JobCard.update({
                status: status
            },
                {
                    where: {
                        id: response.id
                    }
                });
            res.status(201).json({ msg: "Job card successfully cancelled" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function RepairJobCard(req, res) {
    try {
        const status = "Repair";
        const response = await JobCard.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!response)
            return res.status(404).json({ msg: "Jobcard not found" });
        else {
            await JobCard.update({
                status: status
            },
                {
                    where: {
                        id: response.id
                    }
                });
            res.status(201).json({ msg: "Job card do" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    RepairJobCard,
    CancelJobCard,
    countJobCardsRepair,
    countJobCardsDiagonised,
    countJobCardsCancelled,
    countJobCards,
    addNewJobCard,
    updateJobCard,
    RecordMyJobCard,
    getAllJobCards,
    getAllJobCardsToDiagnose,
    getJobCardByCustomerID,
    getJobCardByCardNo
}
