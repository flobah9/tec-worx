const Make = require("../models/Make");
const Category = require("../models/Category");

const getAllMake = async (req, res) => {
    try {
        const response = await Make.findAll({
            attributes: ['uuid', 'id', 'catId', 'make'],
            include: [{
                model: Category,
                attributes: ['category']
            }]
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewMake = async (req, res) => {
    try {
        const { catId, make } = req.body;
        const cat = await Make.findOne({
            where: {
                catId: catId,
                make: make
            }
        });
        if (cat) return res.status(404).json({ msg: "Category already exist for that make" });
        else {
            await Make.create({
                catId: catId,
                make: make
            });
            res.status(201).json({ msg: "Model successfully created" });
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const selectMake = async (req, res) => {
    try {
        const cat = await Make.findAll({
            where: {
                catId: req.params.catId
            },
            include: [{
                model: Category,
                attributes: ['category']
            }]
        });
        if (!cat) return res.status(404).json({ msg: "Category not found" });
        else {
            res.status(200).json(cat);
        }
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const updateMake = async (req, res) => {
    const brand = await Make.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!brand) return res.status(404).json({ msg: "Make not found" });
    const { catId, make } = req.body;
    try {
        await Make.update({
            catId: catId,
            make: make
        }, {
            where: {
                id: brand.id
            }
        });
        res.status(201).json({ msg: "Successfully updated" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const deleteMake = async (req, res) => {
    const make = await Make.findOne({
        where: {
            id: req.params.id
        }
    });
    if (!make) return res.status(404).json({ msg: "Make not found" });
    try {
        await Make.destroy({
            where: {
                id: make.id
            }
        });
        res.status(200).json({ msg: "Make deleted" });
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

const countMake = async (req, res) => {
    try {
        const { count } = await Make.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

module.exports = {
    getAllMake,
    addNewMake,
    selectMake,
    updateMake,
    deleteMake,
    countMake
}
