const PaymentMethod = require ("../models/PaymentMethod");

const AddNewPaymentMethod = async(req, res) =>{
    try {
        const {method, rate, isActive} = req.body;
        const response = await PaymentMethod.findOne({
            where:{
                method: method
            }
        });
        if (response) return res.status(404).json({msg: "Payment method already exists"});
        else{
            await PaymentMethod.create({
                method: method,
                rate: rate,
                isActive: isActive
            })
            res.status(201).json({msg: "Payment method created successfully"});
        }
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

const UpdatePaymentMethod = async(req, res) =>{
    try {
        const {method, rate, isActive} = req.body;
        const response = await PaymentMethod.findOne({
            where:{
                id: req.params.id
            }
        })
        if(!response) return res.status(404).json({msg: "Payment method not found"});
        else{
            await PaymentMethod.update({
                method: method,
                rate: rate,
                isActive: isActive
            },{
                where:{
                    id: response.id
                }
            });
            res.status(201).json({msg: "Successfully updated"});
        }
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

const GetAllPaymentMethods = async(req, res) =>{
    try {
        const response = await PaymentMethod.findAll({
            attributes: ['id', 'method', 'rate', 'isActive', 'updatedAt']
        })
        if(!response) return res.status(404).json({msg: "No data found"});
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

const GetAllActivePaymentMethods = async(req, res)=>{
    try {
        const active = '1';
        const response = await PaymentMethod.findAll({
            attributes: ['id', 'method', 'rate',  'updatedAt'],
            where:{
                isActive: active
            }
        });
        if(!response) return res.status(404).json({msg: "No data found"});
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

module.exports = {
    AddNewPaymentMethod,
    UpdatePaymentMethod,
    GetAllPaymentMethods,
    GetAllActivePaymentMethods
}