const Sales = require('../models/Sales');
const SoldItems = require('../models/SoldItems');
const Stock = require('../models/Inventory');
const Employees = require('../models/Employee');
const sequelize = require("sequelize");

const PointOfSale = async (req, res) => {
    const items = req.body || [];
    try {
        if (items.paidAmount >= items.newTotalAmount) {
            const response = await Sales.create({
                totalAmount: items.totalAmount,
                method: items.method,
                rate: items.rate,
                newTotalAmount: items.newTotalAmount,
                paidAmount: items.paidAmount,
                phone: items.phone,
                cashier: req.userId
            });
            if (response) {
                items?.products.forEach(async (element) => {
                    await SoldItems.create({
                        sales_id: response.id,
                        product: element.product,
                        keepingUnit: element.keepingUnit,
                        price: element.price,
                        quantity: element.quantity,
                        cost: element.totalAmount
                    });
                    const data = await Stock.findOne({
                        where: {
                            keepingUnit: element.keepingUnit
                        }
                    });
                    if (data) {
                        const qty = parseInt(data.quantity) - parseInt(element.quantity)
                        await Stock.update({
                            quantity: qty
                        }, {
                            where: {
                                id: data.id
                            }
                        });
                    } else {
                        return res.status(500).json({ msg: "Something went wrong" });
                    }
                });
                return res.status(200).json({ msg: "Sales is completed" })
            } else {
                return res.status(500).json({ msg: "Something went wrong" });
            }
        } else {
            return res.status(500).json({ msg: "Not enough balance" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetAllSales = async (req, res) => {
    try {
        const response = await Sales.findAll({
            order: [['id', 'DESC']],
            attributes: ['id', 'date', 'phone', 'totalAmount', 'method', 'rate', 'newTotalAmount', 'paidAmount', 'cashier'],
            include: [{
                model: SoldItems,
                attributes: ['product', 'keepingUnit', 'quantity', 'price', 'cost']
            }, {
                model: Employees,
                attributes: ['firstName', 'lastName']
            }]
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetProductCount = async (req, res) => {
    try {
        const response = await SoldItems.findAll({
            attributes: [
                'product', 'keepingUnit',
                [sequelize.fn('sum', sequelize.col('quantity')), 'total_quantity']
            ],
            group: ['product']
        });
        if (!response) return res.status(500).json({ msg: "Something went wrong" });
        res.status(200).json(response)
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetTotalSales = async (req, res) => {
    try {
        const response = await Sales.findAll({
            attributes: [
                'date', 'method',
                [sequelize.fn('monthname', sequelize.col('date')), 'day'],
                [sequelize.fn('sum', sequelize.col('totalAmount')), 'total'],
            ],
            order: [['date', 'ASC']],
            group: ['day'],
        });
        if (!response) return res.status(500).json({ msg: "Something went wrong" });
        res.status(200).json(response)
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    PointOfSale,
    GetAllSales,
    GetProductCount,
    GetTotalSales
}