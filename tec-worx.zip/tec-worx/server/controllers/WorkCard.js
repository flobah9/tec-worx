const JobCards = require("../models/JobCard");
const WorkCards = require("../models/WorkCard");
const RepairCategory = require("../models/orderService/RepairCategory");
const Manufacturer = require("../models/orderService/Manufacturer");
const Employees = require("../models/Employee");
const { Op } = require("sequelize");
const Stock = require("../models/Inventory");
const Requirements = require("../models/Requirements");
const sequelize = require("sequelize");
const easyinvoice = require('easyinvoice');
const fs = require('fs');
const path = require('path');
const dotenv = require("dotenv");
const Customer = require("../models/Customer");
const sgMail = require('@sendgrid/mail');

dotenv.config();

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

let imgPath = path.resolve('Images', 'tecworx.png');

function base64_encode(img) {
    // read binary data
    let png = fs.readFileSync(img);
    // convert binary data to base64 encoded string
    return new Buffer.from(png).toString('base64');
};

const getAllWorkCards = async (req, res) => {
    try {
        const response = await WorkCards.findAll({
            attributes: ['id', 'date', 'cardNo', 'diagnosisResults', 'estimatedTime', 'labourCharge', 'jobdone', 'partsUsed', 'timeTaken', 'technician'],
            include: [{
                model: JobCards,
                attributes: ['model', 'problemDesc', 'status'],
                include: [{
                    model: Make,
                    attributes: ['make'],
                    include: [{
                        model: Category,
                        attributes: ['category']
                    }]
                }]
            }, {
                model: Employees,
                attributes: ['firstName', 'lastName']
            }, {
                model: Requirements,
                attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getWorkCardByCardNo = async (req, res) => {
    try {
        const response = await WorkCards.findOne({
            attributes: ['id', 'date', 'diagnosisResults', 'requirements', 'estimatedTime', 'labourCharge', 'jobdone', 'partsUsed', 'timeTaken'],
            where: {
                cardNo: req.params.cardNo
            },
            include: [{
                model: JobCards,
                attributes: ['model', 'problemDesc', 'status'],
                include: [{
                    model: Make,
                    attributes: ['make'],
                    include: [{
                        model: Category,
                        attributes: ['category']
                    }]
                }]
            }, {
                model: Employees,
                attributes: ['firstName', 'lastName']
            }, {
                model: Requirements,
                attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const addNewWorkCard = async (req, res) => {
    const { cardNo, diagnosisResults, otherRequirements, estimatedTime, labourCharge } = req.body;
    const requirements = req.body || [];
    var items = [];
    let datass;
    try {
        const data = await JobCards.findOne({
            where: {
                cardNo: cardNo
            },
            include: [{
                model: Customer,
                attributes: ['fullName', 'email', 'customerID', 'phone', 'address'],
            }]
        });
        if (data) {
            const response = await WorkCards.findOne({
                where: {
                    cardNo: cardNo
                }
            });
            if (response) res.status(404).json({ msg: "Jobcard already diagonised" });
            else {
                const status = "Diagonized";
                if (req.role === 'Technician' || req.role === "Tech-Admin") {
                    const responses = await WorkCards.create({
                        cardNo: cardNo,
                        diagnosisResults: diagnosisResults,
                        otherRequirements: otherRequirements,
                        estimatedTime: estimatedTime,
                        labourCharge: labourCharge,
                        technician: req.userId
                    });
                    if (responses) {
                        requirements?.requirements.forEach(async (element) => {
                            const datas = await Stock.findOne({
                                attributes: ['id', 'keepingUnit', 'product', 'price'],
                                where: {
                                    product: element
                                }
                            });
                            items.push(datas);
                            await Requirements.create({
                                workcard_id: responses.id,
                                keepingUnit: datas.keepingUnit,
                                product: datas.product,
                                price: datas.price
                            });
                        });
                        await JobCards.update({
                            status: status
                        }, {
                            where: {
                                id: data.id
                            }
                        });
                    }
                    else {
                        return res.status(404).json({ msg: "Failed to capture requirements" });
                    }
                }
                else {
                    return res.status(404).json({ msg: "User role can not work in workshop" });
                }
            }
            //generating invoice 
            datass = {
                "images": {
                    // The logo on top of your invoice
                    "logo": `${base64_encode(imgPath)}`,
                },
                // Your company data
                "sender": {
                    "company": "Tecworx Tech Repair",
                    "address": "Avondale Shops, Nando Building, Downstairs",
                    "city": "Harare",
                    "country": "Zimbabwe",
                    "zip": "08677210051",
                    "custom1": "info@tec-worx.com",
                    "custom2": "https://tec-worx.com/",
                },
                // Your recipient
                "client": {
                    "company": `${data?.customer.fullName}`,
                    "address": `${data?.customer.address}`,
                    "zip": `${data?.customer.phone}`,
                    "custom1": `${data?.customer.email}`,
                    "custom2": `${data.customerID}`,
                },
                "information": {
                    // Invoice number
                    "number": `${data.cardNo}`,
                    // Invoice data
                    "date": `${new Date(new Date().setDate(new Date().getDate()))}`,
                    // Invoice due date
                    "due-date": `${new Date(new Date().setDate(new Date().getDate() + 7))}`
                },
                // The products you would like to see on your invoice
                // Total values are being calculated automatically
                "products": [
                    {
                        "quantity": 1,
                        "description": "Labour Charge",
                        "tax-rate": 0,
                        "price": `${labourCharge}`,
                    }
                ],
                "bottom-notice": "Kindly pay your invoice within 7 days.",
                "settings": {
                    "currency": "USD", // See documentation 'Locales and Currency' for more info. Leave empty for no currency.
                    // "locale": "nl-NL", // Defaults to en-US, used for number formatting (See documentation 'Locales and Currency')
                    // "tax-notation": "gst", // Defaults to 'vat'
                    // "margin-top": 25, // Defaults to '25'
                    // "margin-right": 25, // Defaults to '25'
                    // "margin-left": 25, // Defaults to '25'
                    // "margin-bottom": 25, // Defaults to '25'
                    // "format": "A4", // Defaults to A4, options: A3, A4, A5, Legal, Letter, Tabloid
                    // "height": "1000px", // allowed units: mm, cm, in, px
                    // "width": "500px", // allowed units: mm, cm, in, px
                    // "orientation": "landscape", // portrait or landscape, defaults to portrait
                },
                "translate": {
                    // "invoice": "FACTUUR",  // Default to 'INVOICE'
                    // "number": "Nummer", // Defaults to 'Number'
                    // "date": "Datum", // Default to 'Date'
                    // "due-date": "Verloopdatum", // Defaults to 'Due Date'
                    // "subtotal": "Subtotaal", // Defaults to 'Subtotal'
                    // "products": "Producten", // Defaults to 'Products'
                    // "quantity": "Aantal", // Default to 'Quantity'
                    // "price": "Prijs", // Defaults to 'Price'
                    // "product-total": "Totaal", // Defaults to 'Total'
                    // "total": "Totaal" // Defaults to 'Total'
                },
            }
            items?.forEach(async element => {
                datass.products.push(
                    {
                        "quantity": 1,
                        "description": `${element.product}`,
                        "tax-rate": 0,
                        "price": `${element.price}`,
                    }
                )
            });
            let result = await easyinvoice.createInvoice(datass);
            const folderPath = 'Images/Invoice/'
            const filename = `invoice${Date.now()}.pdf`
            const filePath = path.join(folderPath, filename)
            try {
                fs.writeFileSync(filePath, result.pdf, 'base64');
            } catch (error) {
                res.status(500).json({ msg: error.message });
            }

            const attach = await WorkCards.update({
                invoice: filePath.replace(/\\/g, '/'),
            }, {
                where: {
                    cardNo: cardNo
                }
            });

            if (attach) {
                const attachment = fs.readFileSync(filePath).toString("base64");

                const msg = {
                    from: 'manflobah9@gmail.com',
                    to: `${data?.customer.email}`,
                    subject: 'Invoice for jobcard ' + `${data.cardNo}`,
                    text: 'Good day, diagnosis for your device is complete elow is an attachment of the invoice. Get in touch with us so that we can proceed to the next stage',
                    attachments: [
                        {
                            content: attachment,
                            filename: filename,
                            type: "application/pdf",
                            disposition: "attachment"
                        }
                    ]
                };
                sgMail.send(msg).catch(err => {
                    console.log(err);
                });
            }
            res.status(201).json({ msg: "Work card successfully created" });
        }
        else {
            return res.status(404).json({ msg: "Jobcard does not exists" });
        }
    } catch (error) {
        return res.status(500).json({ msg: error.message });
    }
}

const viewMyWork = async (req, res) => {
    try {
        const response = await WorkCards.findAll({
            attributes: ['id', 'date', 'diagnosisResults', 'estimatedTime', 'jobdone', 'timeTaken'],
            where: {
                technician: req.userId
            },
            include: [{
                model: Requirements,
                attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
            }, {
                model: JobCards,
                attributes: ['cardNo', 'model', 'problemDesc', 'status'],
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }]
        });
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const updateWorkCard = async (req, res) => {
    try {
        const cstatus = "Repair";
        const response = await WorkCards.findOne({
            where: {
                id: req.params.id,
            },
            include: [{
                model: Requirements,
                attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
            }, {
                model: JobCards,
                where: {
                    status: cstatus
                }
            }]
        })
        if (!response) return res.status(404).json({ msg: "Workcard not found" });
        else {
            const { jobdone, partsUsed, timeTaken, otherRequirementsUsed } = req.body;
            const status = "Complete";
            if (req.role === 'Technician' || req.role === "Tech-Admin") {
                if (req.userId !== response.technician) return res.status(403).json({ msg: "Access forbidden" });
                else {
                    await WorkCards.update({
                        jobdone: jobdone,
                        partsUsed: partsUsed,
                        timeTaken: timeTaken,
                        otherRequirementsUsed: otherRequirementsUsed
                    }, {
                        where: {
                            [Op.and]: [{ id: response.id }, { technician: req.userId }]
                        }
                    });
                    await JobCards.update({
                        status: status
                    }, {
                        where: {
                            cardNo: response.cardNo
                        }
                    });
                    res.status(200).json({ msg: "WorkCard updated successfuly" });
                }
            }
            else {
                res.status(404).json({ msg: "Permission denied" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getWorkCardForRepair = async (req, res) => {
    try {
        const cstatus = "Repair";
        const response = await WorkCards.findAll({
            attributes: ['id', 'date', 'cardNo', 'diagnosisResults', 'otherRequirements', 'estimatedTime'],
            where: {
                technician: req.userId
            },
            include: [{
                model: Requirements,
                attributes: ['id', 'workcard_id', 'keepingUnit', 'product', 'price']
            }, {
                model: JobCards,
                attributes: ['model', 'problemDesc'],
                where: {
                    status: cstatus
                },
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }]
        });
        if (!response) return res.status(403).json({ msg: "Access forbidden" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const countWorkCards = async (req, res) => {
    try {
        const { count } = await WorkCards.findAndCountAll()
        res.status(200).json(count);
    } catch (error) {
        console.log(error)
    }
}

const TechnicianByNumber = async (req, res) => {
    try {
        const response = await WorkCards.findAll({
            attributes: [
                [sequelize.fn('count', sequelize.col('workshop.id')), 'total'],
                [sequelize.col('employee.lastName'), 'lastName']
            ],
            include: [{
                model: Employees,
                attributes: ['firstName']
            }],
            group: ['lastName'],
        });
        if (!response) return res.status(500).json({ msg: "Something went wrong" });
        res.status(200).json(response)
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const countMyWorkCard = async (req, res) => {
    try {
        const { count } = await WorkCards.findAndCountAll({
            where: {
                technician: req.userId
            }
        })
        res.status(200).json(count);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    countMyWorkCard,
    TechnicianByNumber,
    countWorkCards,
    getWorkCardForRepair,
    updateWorkCard,
    viewMyWork,
    addNewWorkCard,
    getWorkCardByCardNo,
    getAllWorkCards
}

