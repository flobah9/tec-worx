const RepairCategory= require ("../../models/orderService/RepairCategory");
const Manufacturer= require ("../../models/orderService/Manufacturer");

const addNewManufacturer = async (req, res) => {
    const { repairId, manufacture } = req.body;
    try {
        const response = await Manufacturer.findOne({
            where: {
                repairId: repairId,
                manufacture: manufacture
            }
        });
        if (response) return res.status(404).json({ msg: "Repair Category already exist for that manufacturer" });
        else {
            await Manufacturer.create({
                repairId: repairId,
                manufacture: manufacture,
                image: req.file?.path.replace(/\\/g, '/')
            })
            res.status(201).json({ msg: "Manufacturer successfully created" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const updateManufacturer = async (req, res) => {
    const { repairId, manufacture } = req.body;
    try {
        const response = await Manufacturer.findOne({
            where: {
                id: req.body.id
            }
        });
        if (!response) return res.status(404).json({ msg: "Manufacturer not found" });
        else {
            await Manufacturer.update({
                repairId: repairId,
                manufacture: manufacture
            }, {
                where: {
                    id: response.id
                }
            })
            res.status(201).json({ msg: "Successfully updated" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const selectManufacturerByRepair = async (req, res) => {
    try {
        const response = await Manufacturer.findAll({
            where: {
                repairId: req.params.repairId
            },
            include: [{
                model: RepairCategory,
                attributes: ['repair']
            }]
        });
        if (!response) return res.status(404).json({ msg: "Repair Category not found" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getAllManufacturer = async (req, res) => {
    try {
        const response = await Manufacturer.findAll({
            attributes: ['id', 'manufacture', 'image', 'repairId'],
            include: [{
                model: RepairCategory,
                attributes: ['repair']
            }]
        })
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetManufactureById = async (req, res) => {
    try {
        const response = await Manufacturer.findOne({
            attributes: ['id', 'repairId', 'manufacture'],
            where: {
                id: req.body.makeId
            }
        });
        if (!response) return res.status(404).json({ msg: "Manufacturer not found" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports={
    addNewManufacturer,
    updateManufacturer,
    selectManufacturerByRepair,
    getAllManufacturer,
    GetManufactureById
}