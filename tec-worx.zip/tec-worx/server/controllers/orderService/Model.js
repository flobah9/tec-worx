const Manufacturer = require("../../models/orderService/Manufacturer");
const DeviceModel = require("../../models/orderService/Model");
const RepairCategory = require("../../models/orderService/RepairCategory");

const addNewDeviceModel = async (req, res) => {
    const { manufactureId, model, repairId } = req.body;
    try {
        const response = await DeviceModel.findOne({
            where: {
                repairId: repairId,
                manufactureId: manufactureId,
                model: model
            }
        })
        if (response) return res.status(404).json({ msg: "Model already exists" });
        else {
            await DeviceModel.create({
                repairId: repairId,
                manufactureId: manufactureId,
                model: model,
                image: req.file?.path.replace(/\\/g, '/')
            })
            res.status(201).json({ msg: "Model successfully created" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const updateDeviceModel = async (req, res) => {
    const { manufactureId, model } = req.body;
    try {
        const response = await DeviceModel.findOne({
            where: {
                id: req.body.id
            }
        })
        if (!response) return res.status(404).json({ msg: "Model does not exists" });
        else {
            await DeviceModel.update({
                manufactureId: manufactureId,
                model: model
            }, {
                where: {
                    id: response.id
                }
            })
            res.status(201).json({ msg: "Successfully updated" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const selectModelByManufacture = async (req, res) => {
    try {
        const response = await DeviceModel.findAll({
            attributes: ['id', 'model', 'image', 'manufactureId', 'repairId'],
            where: {
                manufactureId: req.params.manufactureId
            },
            include: [{
                model: Manufacturer,
                attributes: ['id', 'manufacture'],
                include: [{
                    model: RepairCategory,
                    attributes: ['id', 'repair']
                }]
            }]
        })
        if (!response) return res.status(404).json({ msg: "Manufacturer not found" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getAllDeviceModel = async (req, res) => {
    try {
        const response = await DeviceModel.findAll({
            attributes: ['id', 'model', 'image', 'repairId', 'manufactureId'],
            include: [{
                model: Manufacturer,
                attributes: ['manufacture'],
                include: [{
                    model: RepairCategory,
                    attributes: ['repair']
                }]
            }]
        })
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    getAllDeviceModel,
    selectModelByManufacture,
    updateDeviceModel,
    addNewDeviceModel
}