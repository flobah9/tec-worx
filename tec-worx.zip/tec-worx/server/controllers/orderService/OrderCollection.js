const OrderCollection = require("../../models/orderService/OrderCollection");
const OrderService = require("../../models/orderService/OrderService");
const OrderPayments = require('../../models/orderService/OrderPayments');
const sequelize = require("sequelize");

const AddOrderCollectionRecord = async (req, res) => {
    const { customerID, orderId, collectedBy, fullName, phone, isCollected } = req.body;
    try {
        const response = await OrderService.findOne({
            where: {
                id: req.body.id
            }
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            if (response.status === "Cancelled") {
                const data = await OrderCollection.create({
                    customerID: customerID,
                    orderId: orderId,
                    collectedBy: collectedBy,
                    fullName: fullName,
                    phone: phone,
                    user: req.userId
                });
                if (!data) return res.status(404).json({ msg: "Failed to capture data therefore jobcard can not be collected" });
                else {
                    await OrderService.update({
                        isCollected: isCollected
                    },
                        {
                            where: {
                                id: response.id
                            }
                        });
                    res.status(201).json({ msg: "Device collected successfully" });
                }
            }
            else if (response.status === "Complete") {
                const payment = await OrderPayments.findAll({
                    attributes: ['id', 'orderId', 'totalAmount',
                        [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
                    group: ['orderId'],
                    raw: true,
                    where: {
                        orderId: orderId
                    }
                });
                if (payment.map(x => x.paidSum) >= payment.map(x => x.totalAmount)) {
                    const completed = await OrderCollection.create({
                        customerID: customerID,
                        orderId: orderId,
                        collectedBy: collectedBy,
                        fullName: fullName,
                        phone: phone,
                        user: req.userId
                    });
                    if (!completed) return res.status(404).json({ msg: "Failed to capture data therefore jobcard can not be collected" });
                    else {
                        await OrderService.update({
                            isCollected: isCollected
                        },
                            {
                                where: {
                                    id: response.id
                                }
                            });
                        res.status(201).json({ msg: "Device collected successfully" });
                    }
                } else {
                    res.status(404).json({ msg: "Please clear the outstanding balance" });
                }
            } else {
                res.status(404).json({ msg: "Device can not be collected at this stage" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    AddOrderCollectionRecord
}