const OrderPayments = require('../../models/orderService/OrderPayments');
const OrderService = require('../../models/orderService/OrderService');
const WorkOrders = require('../../models/orderService/WorkOrder');
const Partsrequired = require('../../models/orderService/Partsrequired');
const Sales = require('../../models/Sales');
const SoldItems = require('../../models/SoldItems');
const Stock = require('../../models/Inventory');
const sequelize = require("sequelize");
const { Op } = require("sequelize");

const PayForOrder = async (req, res) => {
    const items = req.body || [];
    const status = "Repair";
    try {
        const response = await OrderService.findOne({
            attributes: ['id', 'orderId', 'status'],
            where: {
                orderId: items.orderId
            },
            include: [{
                model: WorkOrders,
                attributes: ['id', 'labourCharge'],
                include: [{
                    model: Partsrequired,
                    attributes: ['workorder_id', 'keepingUnit', 'product', 'price', 'isToBePaid', 'isPaidFor', 'id']
                }]
            }]
        })
        if (!response) return res.status(500).json({ msg: "Order not found" });
        else {
            const data = await OrderPayments.create({
                orderId: items.orderId,
                totalAmount: items.totalAmount,
                paidAmount: items.paidAmount,
                user: req.userId
            });
            if (!data) return res.status(404).json({ msg: "Something went wrong" });
            else {
                if (!(response.status === status || response.status === "Complete")) {
                    await OrderService.update({
                        status: status
                    }, {
                        where: {
                            id: response.id
                        }
                    });
                }
                if (!(items.products.length === 0)) {
                    const totalAmountForCard = parseFloat(items.totalAmount).toFixed(2);
                    const paidAmountForOrder = parseFloat(items.paidAmount).toFixed(2);
                    if (!(totalAmountForCard === paidAmountForOrder) || totalAmountForCard >= paidAmountForOrder) {
                        items.products?.forEach(async (element) => {
                            await Partsrequired.update({
                                isToBePaid: 1
                            }, {
                                where: {
                                    [Op.and]: [
                                        { workorder_id: response.orderswork?.partsrequireds?.map(x => x.workorder_id) },
                                        { keepingUnit: element.keepingUnit }
                                    ]
                                }
                            });
                        });
                    }
                    else {
                        let newTotal = parseFloat(items.totalAmount).toFixed(2) - parseFloat(response.orderswork.labourCharge).toFixed(2)
                        const totalSum = parseFloat(newTotal).toFixed(2);
                        const sales = await Sales.create({
                            totalAmount: totalSum,
                            method: items.method,
                            rate: items.rate,
                            newTotalAmount: totalSum,
                            paidAmount: items.paidAmount,
                            phone: items.phone,
                            cashier: req.userId
                        });
                        if (sales) {
                            await OrderPayments.update({
                                sales_id: sales.id
                            }, {
                                where: {
                                    id: data.id
                                }
                            });
                            items.products?.forEach(async (element) => {
                                await SoldItems.create({
                                    sales_id: sales.id,
                                    product: element.product,
                                    keepingUnit: element.keepingUnit,
                                    price: element.price,
                                    quantity: 1,
                                    cost: element.price
                                });
                                const item = await Stock.findOne({
                                    where: {
                                        keepingUnit: element.keepingUnit
                                    }
                                });
                                if (item) {
                                    const qty = parseInt(item.quantity) - parseInt(1)
                                    await Stock.update({
                                        quantity: qty
                                    }, {
                                        where: {
                                            id: item.id
                                        }
                                    });
                                }
                                await Partsrequired.update({
                                    isPaidFor: 1
                                }, {
                                    where: {
                                        [Op.and]: [
                                            { workorder_id: response.orderswork?.partsrequireds?.map(x => x.workorder_id) },
                                            { keepingUnit: element.keepingUnit }
                                        ]
                                    }
                                });
                            });
                        }
                    }
                }
                res.status(200).json({ msg: "Transaction is completed" })
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const UpdatePayForOrder = async (req, res) => {
    try {
        const { amount, orderId, method, rate, phone } = req.body;
        const response = await OrderPayments.findAll({
            attributes: ['orderId', 'totalAmount', 'id',
                [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
            group: ['orderId'],
            raw: true,
            where: {
                orderId: orderId,
            }
        });
        if (!response) return res.status(404).json({ msg: "Something went wrong" });
        else {
            const paid = response.map(x => x.paidSum)
            const totalAmount = response.map(x => x.totalAmount)
            const current = await OrderPayments.create({
                orderId: orderId,
                paidAmount: amount,
                totalAmount: totalAmount,
                user: req.userId
            });
            if (!paid) return res.status(404).json({ msg: "Something went wrong" });
            else {
                const newPaid = parseFloat(paid) + parseFloat(amount)
                if (newPaid >= parseFloat(totalAmount).toFixed(2)) {
                    const data = await WorkOrders.findOne({
                        attributes: ['id', 'labourCharge'],
                        where: {
                            orderId: orderId
                        }
                    });
                    if (!data) return res.status(404).json({ msg: "Something went wrong" });
                    else {
                        const items = await Partsrequired.findAll({
                            attributes: [
                                'workorder_id', 'keepingUnit', 'product', 'id', 'price'
                            ],
                            group: ['id'],
                            raw: true,
                            where: {
                                [Op.and]: [
                                    { workorder_id: data.id },
                                    { isToBePaid: 1 }
                                ]

                            }
                        });
                        if (items) {
                            const value = eval(items.map(x => x.price).join('+'))
                            const sum = parseFloat(value) * parseFloat(rate)
                            const finalAmount = parseFloat(sum).toFixed(2)
                            const paying = parseFloat(newPaid) * parseFloat(rate)
                            const paidAmount = parseFloat(paying).toFixed(2)
                            const sales = await Sales.create({
                                totalAmount: parseFloat(value).toFixed(2),
                                paidAmount: newPaid,
                                method: method,
                                rate: rate,
                                newTotalAmount: finalAmount,
                                paidAmount: paidAmount,
                                phone: phone,
                                cashier: req.userId
                            });
                            if (sales) {
                                await OrderPayments.update({
                                    sales_id: sales.id
                                }, {
                                    where: {
                                        id: current.id
                                    }
                                });
                                items?.forEach(async (element) => {
                                    const totalItemCost = parseFloat(element.price) * parseInt(1)
                                    await SoldItems.create({
                                        sales_id: sales.id,
                                        product: element.product,
                                        keepingUnit: element.keepingUnit,
                                        price: element.price,
                                        quantity: 1,
                                        cost: totalItemCost
                                    });
                                    await Partsrequired.update({
                                        isPaidFor: 1
                                    }, {
                                        where: {
                                            [Op.and]: [
                                                { workorder_id: data.id },
                                                { keepingUnit: element.keepingUnit }
                                            ]
                                        }
                                    });
                                    const item = await Stock.findOne({
                                        where: {
                                            keepingUnit: element.keepingUnit
                                        }
                                    });
                                    if (item) {
                                        const qty = parseInt(item.quantity) - parseInt(1)
                                        await Stock.update({
                                            quantity: qty
                                        }, {
                                            where: {
                                                id: item.id
                                            }
                                        });
                                    }
                                })
                            }
                        }
                    }
                }
                res.status(200).json({ msg: "Transaction is completed" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindOrderPayment = async (req, res) => {
    try {
        const response = await OrderPayments.findAll({
            model: OrderPayments,
            attributes: ['id', 'date', 'totalAmount', 'orderId',
                [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
            group: ['orderId'],
            where: {
                orderId: req.params.orderId
            }
        })
        if (!response) return res.status(404).json({ msg: "" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindCustomerOrderPayments = async (req, res) => {
    try {
        const response = await OrderService.findAll({
            where: {
                customerId: req.customerId
            }
        });
        var value = []
        if (!response) return res.status(404).json({ msg: "Error" });
        else {
            for (let index = 0; index < response.length; index++) {
                const element = await OrderPayments.findAll({
                    attributes: ['id', 'orderId', 'totalAmount', 'date', 'paidAmount'],
                    order: [['orderId', 'ASC']],
                    raw: true,
                    where: {
                        orderId: response[index].orderId
                    }
                })
                value.push(element)
            }
            res.status(200).json(value);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const FindAllOrderPayments = async (req, res) => {
    try {
        const response = await OrderService.findAll();
        var value = []
        if (!response) return res.status(404).json({ msg: "Error" });
        else {
            for (let index = 0; index < response.length; index++) {
                const element = await OrderPayments.findAll({
                    attributes: ['id', 'orderId', 'totalAmount', 'date',
                        [sequelize.fn('sum', sequelize.col('paidAmount')), 'paidSum']],
                    group: ['orderId'],
                    raw: true,
                    where: {
                        orderId: response[index].orderId
                    }
                })
                value.push(element)
            }
            res.status(200).json(value);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    FindAllOrderPayments,
    FindCustomerOrderPayments,
    FindOrderPayment,
    UpdatePayForOrder,
    PayForOrder
}
