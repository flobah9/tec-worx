const OrderService = require("../../models/orderService/OrderService");
const DeviceModel = require("../../models/orderService/Model");
const Customer = require("../../models/Customer");
const RepairCategory = require("../../models/orderService/RepairCategory");
const Manufacturer = require("../../models/orderService/Manufacturer");
const Employees = require("../../models/Employee");
const WorkOrders = require("../../models/orderService/WorkOrder");
const OrderedServices = require("../../models/orderService/OrderedServices");
const Partsrequired = require("../../models/orderService/Partsrequired");
const OrderPayments = require("../../models/orderService/OrderPayments");
const sequelize = require("sequelize");
const { Op } = require("sequelize");
const sgMail = require('@sendgrid/mail')
const dotenv = require("dotenv");
dotenv.config();

sgMail.setApiKey(process.env.SENDGRID_API_KEY)

const OrderAService = async (req, res) => {
    try {
        const { modelId, bookedDate } = req.body;
        const services = req.body || [];
        const data = await OrderService.findOne({
            where: {
                bookedDate: bookedDate,
            }
        });
        if (data) return res.status(404).json({ msg: "Time is occupied try choose either different day or time" });
        const response = await OrderService.create({
            modelId: modelId,
            bookedDate: bookedDate,
            customerId: req.customerId
        });
        if (response) {
            services.services?.forEach(async (element) => {
                await OrderedServices.create({
                    order_id: response.id,
                    problem_id: element.id,
                    problem: element.problem,
                    repairCost: element.repairCost
                })
            });
            const employees = await Employees.findAll({
                attributes: ['id', 'email'],
                where: {
                    [Op.or]: [
                        { role: { [Op.like]: '%Admin%' } }
                    ]
                }
            });
            if (employees) {
                employees.forEach((element) => {
                    const message = {
                        from: 'manflobah9@gmail.com',
                        to: `${element.email}`,
                        subject: 'Alert!!! new jobcard',
                        text: 'Good day kindly note that there is a service that has been ordered that requires attetion ',
                    };
                    sgMail
                        .send(message)
                        .then(() => {
                            console.log('Email sent')
                        })
                        .catch((error) => {
                            console.error(error)
                        })
                })
            } else {
                res.status(404).json({ msg: "Failed to order for service" });
            }
            res.status(200).json({ msg: 'Order is a success' });
        }
        else {
            res.status(404).json({ msg: "Failed to order for service" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const OrderServiceForCustomer = async (req, res) => {
    try {
        const { modelId, bookedDate, customerId } = req.body;
        const services = req.body || [];
        const data = await OrderService.findOne({
            where: {
                bookedDate: bookedDate,
            }
        });
        if (data) return res.status(404).json({ msg: "Time is occupied try choose either different day or time" });
        const response = await OrderService.create({
            modelId: modelId,
            bookedDate: bookedDate,
            customerId: customerId
        });
        if (response) {
            services.services?.forEach(async (element) => {
                await OrderedServices.create({
                    order_id: response.id,
                    problem_id: element.id,
                    problem: element.problem,
                    repairCost: element.repairCost
                })
            });
            const employees = await Employees.findAll({
                attributes: ['id', 'email'],
                where: {
                    [Op.or]: [
                        { role: { [Op.like]: '%Admin%' } }
                    ]
                }
            });
            if (employees) {
                employees.forEach((element) => {
                    const message = {
                        from: 'manflobah9@gmail.com',
                        to: `${element.email}`,
                        subject: 'Alert!!! new jobcard',
                        text: 'Good day kindly note that there is a service that has been ordered that requires attetion ',
                    };
                    // sgMail
                    //     .send(message)
                    //     .then(() => {
                    //         console.log('Email sent')
                    //     })
                    //     .catch((error) => {
                    //         console.error(error)
                    //     })
                })
            } else {
                res.status(404).json({ msg: "Failed to order for service" });
            }
            res.status(200).json({ msg: 'Order is a success' });
        }
        else {
            res.status(404).json({ msg: "Failed to order for service" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetAllOrderedServices = async (req, res) => {
    try {
        const response = await OrderService.findAll({
            order: [['id', 'DESC']],
            attributes: ['id', 'date', 'bookedDate', 'status', 'orderId', 'isCollected'],
            include: [{
                model: DeviceModel,
                attributes: ['model'],
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }, {
                model: OrderedServices,
                attributes: ['id', 'order_id', 'problem', 'repairCost']
            }, {
                model: Customer,
                attributes: ['fullName', 'customerID']
            }, {
                model: WorkOrders,
                attributes: ['otherParts', 'timeEstimate', 'labourCharge', 'date'],
                include: [{
                    model: Partsrequired,
                    attributes: ['id', 'keepingUnit', 'product', 'price']
                }, {
                    model: Employees,
                    attributes: ['firstName', 'lastName']
                }]
            }]
        })
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetOrderServiceByCustomerId = async (req, res) => {
    try {
        const response = await OrderService.findAll({
            order: [['id', 'DESC']],
            attributes: ['id', 'date', 'orderId', 'bookedDate', 'status'],
            where: {
                customerId: req.customerId
            },
            include: [{
                model: DeviceModel,
                attributes: ['model'],
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }, {
                model: OrderedServices,
                attributes: ['id', 'order_id', 'problem', 'repairCost']
            }]
        })
        if (response) res.status(200).json(response);
        else {
            res.status(404).json({ msg: "Error on retrieving data" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const RescheduleAppointment = async (req, res) => {
    try {
        const { reschedule } = req.body;

        const response = await OrderService.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            await OrderService.update({
                bookedDate: reschedule,
            },
                {
                    where: {
                        id: response.id
                    }
                });
            res.status(200).json({ msg: "Order rescheduled successfuly" })
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const CancelAppointment = async (req, res) => {
    try {
        const status = "Cancelled"
        const response = await OrderService.findOne({
            where: {
                id: req.params.id
            }
        })
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            const statuz = "Repairing";
            const statuzz = "Complete";
            if (response.status === statuz || response.status === statuzz || response.status === status) {
                res.status(404).json({ msg: "Failed to cancel the order" });
            }
            else {
                await OrderService.update({
                    status: status
                }, {
                    where: {
                        [Op.and]: [{ id: response.id }, { customerId: req.customerId }]
                    }
                });
                res.status(200).json({ msg: "Order updated successfuly" })
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetOrderByOrderNo = async (req, res) => {
    try {
        const response = await OrderService.findOne({
            attributes: ['date', 'orderId'],
            where: {
                orderId: req.params.orderId
            },
            include: [{
                model: DeviceModel,
                attributes: ['model']
            }, {
                model: OrderedServices,
                attributes: ['id', 'problem', 'repairCost']
            }, {
                model: Customer,
                attributes: ['customerID', 'phone']
            }, {
                model: WorkOrders,
                attributes: ['labourCharge', 'timeEstimate', 'otherParts'],
                include: [{
                    model: Partsrequired,
                    attributes: ['id', 'keepingUnit', 'product', 'price']
                }]
            }]
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const CountMyJobServices = async (req, res) => {
    try {
        const { count } = await OrderService.findAndCountAll({
            where: {
                customerId: req.customerId
            }
        });
        res.status(200).json(count);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const CountOrders = async (req, res) => {
    try {
        const { count } = await OrderService.findAndCountAll();
        res.status(200).json(count);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

async function RepairOrder(req, res) {
    try {
        const status = "Repair";
        const response = await OrderService.findOne({
            where: {
                id: req.params.id
            }
        });
        if (!response)
            return res.status(404).json({ msg: "Order not found" });
        else {
            await OrderService.update({
                status: status
            },
                {
                    where: {
                        id: response.id
                    }
                });
            res.status(201).json({ msg: "Job card do" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    RepairOrder,
    CountOrders,
    CountMyJobServices,
    GetAllOrderedServices,
    GetOrderByOrderNo,
    CancelAppointment,
    RescheduleAppointment,
    OrderServiceForCustomer,
    OrderAService,
    GetOrderServiceByCustomerId
}