const DeviceModel = require("../../models/orderService/Model");
const ModelProblems = require("../../models/orderService/Problem");
const Manufacturer = require("../../models/orderService/Manufacturer");
const RepairCategory = require("../../models/orderService/RepairCategory");

const addNewDeviceModelProblem = async (req, res) => {
    try {
        const { modelId, problem, repairCost, repairId, manufactureId } = req.body;
        const response = await ModelProblems.findOne({
            where: {
                repairId: repairId,
                manufactureId: manufactureId,
                modelId: modelId,
                problem: problem
            }
        })
        if (response) return res.status(404).json({ msg: "Model already exists" });
        else {
            await ModelProblems.create({
                repairId: repairId,
                manufactureId: manufactureId,
                modelId: modelId,
                problem: problem,
                repairCost: repairCost
            })
            res.status(201).json({ msg: "Model successfully created" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const updateDeviceModelProblem = async (req, res) => {
    try {
        const { modelId, problem, repairCost, repairId, manufactureId } = req.body;
        const response = await ModelProblems.findOne({
            where: {
                id: req.params.id
            }
        })
        if (!response) return res.status(404).json({ msg: "Problem does not exists" });
        else {
            await ModelProblems.update({
                repairId: repairId,
                manufactureId: manufactureId,
                modelId: modelId,
                problem: problem,
                repairCost: repairCost
            },
                {
                    where: {
                        id: response.id
                    }
                });
            res.status(201).json({ msg: "Successfully updated" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const selectProblemByDeviceModel = async (req, res) => {
    try {
        const response = await ModelProblems.findAll({
            attributes: ['id', 'problem', 'repairCost', 'modelId', 'manufactureId', 'repairId'],
            where: {
                modelId: req.params.modelId
            },
            include: [{
                model: DeviceModel,
                attributes: ['model'],
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }]
        })
        if (!response) return res.status(404).json({ msg: "Manufacturer not found" });
        else {
            res.status(200).json(response);
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const getAllDeviceModelProblems = async (req, res) => {
    try {
        const response = await ModelProblems.findAll({
            attributes: ['id', 'problem', 'repairCost', 'modelId', 'manufactureId', 'repairId'],
            include: [{
                model: DeviceModel,
                attributes: ['model'],
                include: [{
                    model: Manufacturer,
                    attributes: ['manufacture'],
                    include: [{
                        model: RepairCategory,
                        attributes: ['repair']
                    }]
                }]
            }]
        })
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    addNewDeviceModelProblem,
    updateDeviceModelProblem,
    selectProblemByDeviceModel,
    getAllDeviceModelProblems
}