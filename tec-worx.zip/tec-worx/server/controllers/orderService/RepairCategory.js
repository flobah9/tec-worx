const RepairCategory = require ("../../models/orderService/RepairCategory");

const getRepairCategory = async(req, res) =>{
    try {
        const response = await RepairCategory.findAll({
            attributes: ['id', 'repair', 'image']
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

const getRepairCategoryById = async(req, res) =>{
    try {
        const response = await RepairCategory.findOne({
            attributes: ['id', 'repair', 'image'],
            where:{
                id: req.params.catId
            }
        });
        res.status(200).json(response);
    } catch (error) {
        res.status(500).json({msg: error.message});
    }
}

const addNewRepairCategory = async(req, res)=>{
    const {repair} = req.body;
    try {
        const response = await RepairCategory.findOne({
            where:{
                repair: repair
            }
        });
        if (response) return res.status(404).json({msg: "Repair category name already exist"});
        else{
            await RepairCategory.create({
                repair: repair,
                image: req.file?.path.replace(/\\/g, '/')
            });
            res.status(201).json({msg: "Repair category successfully created"});
        }
    } catch (error) {
        res.status(400).json({msg: error.message});
    }
}

const updateRepairCategory = async(req, res) =>{
    try {
        const response = await RepairCategory.findOne({
            where:{
                id: req.body.id
            }
        })
        if(!response) return res.status(404).json({msg: "Repair Category not found"});
        const {repair} = req.body;
        await RepairCategory.update({
            repair: repair
        },{
            where:{
                id: response.id
            }
        })
        res.status(201).json({msg: "Successfully updated"});
    } catch (error) {
        res.status(400).json({msg: error.message});
    }
}

module.exports={
    getRepairCategoryById,
    getRepairCategory,
    addNewRepairCategory,
    updateRepairCategory
}

