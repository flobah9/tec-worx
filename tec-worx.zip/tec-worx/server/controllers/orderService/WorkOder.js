const WorkOrders = require("../../models/orderService/WorkOrder");
const OrderService = require("../../models/orderService/OrderService");
const RepairCategory = require("../../models/orderService/RepairCategory");
const DeviceModel = require("../../models/orderService/Model");
const Manufacturer = require("../../models/orderService/Manufacturer");
const Employees = require("../../models/Employee");
const OrderedServices = require("../../models/orderService/OrderedServices");
const Partsrequired = require("../../models/orderService/Partsrequired");
const Stock = require("../../models/Inventory");
const { Op } = require("sequelize");
const fetch = require('node-fetch')
const dotenv = require("dotenv");
const ModelProblems = require("../../models/orderService/Problem");
dotenv.config();


const AssingTechnician = async (req, res) => {
    try {
        const { orderId, bookedDate, technician } = req.body;
        const status = "Approved";
        const response = await OrderService.findOne({
            where: {
                orderId: orderId
            }
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            const data = await WorkOrders.findOne({
                where: {
                    orderId: orderId
                }
            });
            if (data) return res.status(404).json({ msg: "Order already assigned to technician" });
            else {
                await WorkOrders.create({
                    orderId: orderId,
                    technician: technician
                })
                await OrderService.update({
                    status: status
                }, {
                    where: {
                        id: response.id
                    }
                })
                const data = await Employees.findOne({
                    attributes: ['phone'],
                    where: {
                        id: technician
                    }
                })
                if (!data) return res.status(404).json({ msg: "Technician not found" });
                else {
                    const phone = data.phone;
                    async function run() {
                        const resp = await fetch(
                            'https://us.sms.api.sinch.com/xms/v1/' + process.env.SERVICE_PLAN_ID + '/batches',
                            {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json',
                                    Authorization: 'Bearer ' + process.env.API_TOKEN
                                },
                                body: JSON.stringify({
                                    from: process.env.SINCH_NUMBER,
                                    to: ['+' + phone],
                                    body: 'Good day, a new order have been appointed to you scheduled on ' + bookedDate
                                })
                            }
                        );
                        await resp.json();
                    }
                    run();
                }
                res.status(201).json({ msg: "Order assigned to a technician" });
            }
        }
    }
    catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const WorkOnTheOrder = async (req, res) => {
    try {
        const status = "Approved";
        const newStatus = "Pending";
        const { orderId, otherParts, labourCharge, timeEstimate } = req.body;
        const requirements = req.body || [];
        const response = await WorkOrders.findOne({
            where: {
                orderId: orderId
            }
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            const data = await OrderService.findOne({
                where: {
                    orderId: orderId,
                    status: status
                }
            })
            if (!data) return res.status(404).json({ msg: "Order not assigned to technician" });
            else {
                if (response.labourCharge === null || response.timeEstimate === null) {
                    const order = await WorkOrders.update({
                        Date: Date.now(),
                        otherParts: otherParts,
                        timeEstimate: timeEstimate,
                        labourCharge: labourCharge
                    }, {
                        where: {
                            [Op.and]: [{ id: response.id }, { technician: req.userId }]
                        }
                    });
                    if (order) {
                        requirements?.requirements.forEach(async (element) => {
                            const datas = await Stock.findOne({
                                attributes: ['id', 'keepingUnit', 'product', 'price'],
                                where: {
                                    product: element
                                }
                            });
                            await Partsrequired.create({
                                workorder_id: response.id,
                                keepingUnit: datas.keepingUnit,
                                product: datas.product,
                                price: datas.price
                            });
                        });
                        await OrderService.update({
                            status: newStatus
                        }, {
                            where: {
                                id: data.id
                            }
                        });
                        res.status(201).json({ msg: "Order has updated" });
                    } else {
                        return res.status(404).json({ msg: "Something went wrong" });
                    }
                }
                else {
                    return res.status(404).json({ msg: "Already worked on" });
                }
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const GetMyWorkingOrders = async (req, res) => {
    try {
        const response = await WorkOrders.findAll({
            attributes: ['id', 'otherParts', 'timeEstimate', 'date', 'orderId'],
            where: {
                technician: req.userId
            },
            include: [{
                model: OrderService,
                attributes: ['id', 'date', 'bookedDate', 'status'],
                include: [{
                    model: DeviceModel,
                    attributes: ['model'],
                    include: [{
                        model: Manufacturer,
                        attributes: ['manufacture'],
                        include: [{
                            model: RepairCategory,
                            attributes: ['repair']
                        }]
                    }]
                }, {
                    model: OrderedServices,
                    attributes: ['id', 'order_id', 'problem', 'repairCost']
                }]
            }, {
                model: Partsrequired,
                attributes: ['keepingUnit', 'product', 'price', 'id']
            }]
        })
        if (response) return res.status(201).json(response);
        else {
            res.status(404).json({ msg: "Something went wrong" });
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const updateWorkOrder = async (req, res) => {
    try {
        const cstatus = "Repair";
        const response = await WorkOrders.findOne({
            where: {
                id: req.params.id,
            },
            include: [{
                model: Partsrequired,
                attributes: ['id', 'workorder_id', 'keepingUnit', 'product', 'price']
            }, {
                model: OrderService,
                where: {
                    status: cstatus
                }
            }]
        });
        if (!response) return res.status(404).json({ msg: "Order not found" });
        else {
            const { jobdone, partsUsed, timeTaken, otherPartsUsed } = req.body;
            const status = "Complete";
            if (req.role === 'Technician' || req.role === "Tech-Admin") {
                if (req.userId !== response.technician) return res.status(403).json({ msg: "Access forbidden" });
                else {
                    await WorkOrders.update({
                        jobdone: jobdone,
                        partsUsed: partsUsed,
                        timeTaken: timeTaken,
                        otherPartsUsed: otherPartsUsed
                    }, {
                        where: {
                            [Op.and]: [{ id: response.id }, { technician: req.userId }]
                        }
                    });
                    await OrderService.update({
                        status: status
                    }, {
                        where: {
                            orderId: response.orderId
                        }
                    });
                    res.status(200).json({ msg: "Order updated successfuly" });
                }
            }
            else {
                res.status(404).json({ msg: "Permission denied" });
            }
        }
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

const countMyWorkAssign = async (req, res) => {
    try {
        const { count } = await WorkOrders.findAndCountAll({
            where: {
                technician: req.userId
            }
        })
        res.status(200).json(count);
    } catch (error) {
        res.status(500).json({ msg: error.message });
    }
}

module.exports = {
    AssingTechnician,
    WorkOnTheOrder,
    GetMyWorkingOrders,
    updateWorkOrder,
    countMyWorkAssign
}
