const Customer = require("../models/Customer");

const verifyCustomer = async (req, res, next) => {
    if (!req.session.customerId) {
        return res.status(401).json({ msg: "Please login to your account!" });
    }
    try {
        const user = await Customer.findOne({
            where: {
                uuid: req.session.customerId
            }
        });
        if (!user) return res.status(404).json({ msg: "User not found" });
        req.customerId = user.id;
        req.role = user.role;
        next();
    } catch (error) {
        res.status(400).json({ msg: error.message });
    }
}

module.exports = { verifyCustomer }