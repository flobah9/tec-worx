const { Sequelize, DataTypes } = require('sequelize');
const db = require('../config/Database');
const Sales = require("./Sales");
const JobCards = require('./JobCard');
const Employee = require("./Employee");

const Payments = db.define('cardpayments', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    sales_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    totalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    paidAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

JobCards.hasMany(Payments, {
    sourceKey: 'cardNo',
    foreignKey: 'cardNo'
});

Payments.belongsTo(JobCards, {
    foreignKey: 'cardNo',
    targetKey: 'cardNo'
});

Sales.hasMany(Payments, { foreignKey: 'sales_id' });
Payments.belongsTo(Sales, { foreignKey: 'sales_id' });

Employee.hasMany(Payments, {
    foreignKey: 'user'
});

Payments.belongsTo(Employee, {
    foreignKey: 'user'
});

module.exports = Payments;