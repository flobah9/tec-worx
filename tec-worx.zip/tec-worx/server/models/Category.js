const { DataTypes } = require('sequelize');
const db = require('../config/Database');

const Category = db.define('category', {
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [3, 255]
        }
    }
}, {
    freezeTableName: true
});

module.exports = Category;