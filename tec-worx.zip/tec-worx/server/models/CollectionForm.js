const {  DataTypes } = require('sequelize');
const db = require('../config/Database');
const Customer = require("./Customer");
const JobCards = require("./JobCard");
const Employees = require("./Employee");

const Collection = db.define('collection', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    customerID: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    collectedBy: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fullName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

Customer.hasMany(Collection, {
    sourceKey: 'customerID',
    foreignKey: 'customerID'
});

Collection.belongsTo(Customer, {
    foreignKey: 'customerID',
    targetKey: 'customerID'
});

JobCards.hasOne(Collection, {
    sourceKey: 'cardNo',
    foreignKey: 'cardNo'
});

Collection.belongsTo(JobCards, {
    foreignKey: 'cardNo',
    targetKey: 'cardNo'
});

Employees.hasMany(Collection, {
    foreignKey: 'user'
});

Collection.belongsTo(Employees, {
    foreignKey: 'user'
});

module.exports = Collection;