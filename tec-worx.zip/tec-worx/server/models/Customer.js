const { DataTypes } = require('sequelize');
const db = require('../config/Database');

const Customer = db.define('customers',{
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    customerID:{
        type: DataTypes.STRING,
        allowNull: true,
        unique: true
    },
    fullName:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [5, 255]
        }
    },
    phone:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true,
            len: [9, 15]
        }
    },
    email:{
        type: DataTypes.STRING,
        allowNull: false
    },
    address:{
        type: DataTypes.STRING,
        allowNull: true
    },
    contactPerson:{
        allowNull: true,
        type: DataTypes.STRING
    },
    contactPersonCell:{
        type: DataTypes.STRING,
        allowNull: true
    },
    role:{
        type: DataTypes.STRING,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    }
},{
    freezeTableName: true
});

module.exports = Customer;