const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const JobCards = require('./JobCard');
const Employee = require("./Employee");

const DiagnosisFee = db.define('diagnosisFee', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    amount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    method: {
        type: DataTypes.STRING,
        allowNull: false
    },
    rate: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    finalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

JobCards.hasMany(DiagnosisFee, {
    sourceKey: 'cardNo',
    foreignKey: 'cardNo'
});

DiagnosisFee.belongsTo(JobCards, {
    foreignKey: 'cardNo',
    targetKey: 'cardNo'
});

Employee.hasMany(DiagnosisFee, {
    foreignKey: 'user'
});

DiagnosisFee.belongsTo(Employee, {
    foreignKey: 'user'
});

module.exports = DiagnosisFee;