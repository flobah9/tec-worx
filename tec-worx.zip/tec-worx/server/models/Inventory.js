const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const Category = require('./Category');
const Make = require('./Make');

const Stock = db.define('inventory',{
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    catId:{
      type: DataTypes.INTEGER,
      allowNull: false
    },
    makeId:{
        type: DataTypes.INTEGER,
        allowNull: false
    },
    product:{
        type: DataTypes.STRING,
        allowNull: false
    },
    description:{
        type: DataTypes.STRING,
        allowNull: false
    },
    keepingUnit:{
        type: DataTypes.STRING,
        allowNull: true,
        unique: true
    },
    price:{
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    quantity:{
        type: DataTypes.INTEGER.UNSIGNED.ZEROFILL,
        allowNull: false
    }
},{
    freezeTableName: true
});

Make.hasMany(Stock, {
    foreignKey: 'makeId'
});

Stock.belongsTo(Make, {
    foreignKey: 'makeId'
});

Category.hasMany(Stock, {
    foreignKey: 'catId'
});

Stock.belongsTo(Category, {
    foreignKey: 'catId'
});

module.exports = Stock;
