const {  DataTypes } = require('sequelize');
const db = require('../config/Database');
const Customer = require("./Customer");
const Manufacturer = require("./orderService/Manufacturer");
const RepairCategory = require("./orderService/RepairCategory");

const JobCards = db.define('jobcards', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: true,
        unique: true
    },
    date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    customerID: {
        type: DataTypes.STRING,
        allowNull: false
    },
    catId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    makeId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    model: {
        type: DataTypes.STRING,
        allowNull: false
    },
    serialNo: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    problemDesc: {
        type: DataTypes.STRING,
        allowNull: false
    },
    comments: {
        type: DataTypes.STRING,
        allowNull: true
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true
    },
    status: {
        type: DataTypes.STRING,
        allowNull: true
    },
    isCollected: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    }
}, {
    freezeTableName: true
});

Customer.hasMany(JobCards, {
    sourceKey: 'customerID',
    foreignKey: 'customerID'
});

JobCards.belongsTo(Customer, {
    foreignKey: 'customerID',
    targetKey: 'customerID'
});


Manufacturer.hasMany(JobCards, {
    foreignKey: 'makeId'
});
JobCards.belongsTo(Manufacturer, {
    foreignKey: 'makeId'
});

RepairCategory.hasMany(JobCards, {
    foreignKey: 'catId'
});

JobCards.belongsTo(RepairCategory, {
    foreignKey: 'catId'
});

module.exports = JobCards;
