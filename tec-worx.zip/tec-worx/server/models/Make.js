const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const Category = require('./Category');

const Make = db.define('brand', {
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    catId:{
        type: DataTypes.INTEGER,
        allowNull: false
    },
    make: {
        type: DataTypes.STRING,
        allowNull: false
    },
}, {
    freezeTableName: true
});

Category.hasMany(Make, {
    foreignKey: 'catId'
});

Make.belongsTo(Category, {
    foreignKey: 'catId'
});

module.exports = Make;