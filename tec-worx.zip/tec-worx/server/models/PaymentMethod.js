const { Sequelize, DataTypes } = require('sequelize');
const db = require('../config/Database');

const PaymentMethod = db.define('paymentmethod', {
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    method:{
        type: DataTypes.STRING,
        allowNull: false
    },
    rate:{
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    isActive:{
        type:DataTypes.BOOLEAN,
        allowNull: false
    }
}, {
    freezeTableName: true
});

module.exports= PaymentMethod;