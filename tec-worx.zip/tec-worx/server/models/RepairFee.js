const { Sequelize, DataTypes } = require('sequelize');
const db = require('../config/Database');
const Sales = require( "./Sales");
const JobCards = require( './JobCard');
const Employee = require( "./Employee");

const RepairFee = db.define('repairFee', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    labourCharge: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

JobCards.hasMany(RepairFee, {
    sourceKey: 'cardNo',
    foreignKey: 'cardNo'
});

RepairFee.belongsTo(JobCards, {
    foreignKey: 'cardNo',
    targetKey: 'cardNo'
});

module.exports = RepairFee;