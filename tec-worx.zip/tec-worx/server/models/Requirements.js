const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const WorkCards = require( "./WorkCard");
const Stock = require( "./Inventory");

const Requirements = db.define('requirements',{
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    workcard_id:{
        type: DataTypes.INTEGER,
        allowNull: false
    },
    keepingUnit:{
        type: DataTypes.STRING,
        allowNull:false
    },
    product:{   
        type: DataTypes.STRING, 
        allowNull:false
    },
    price:{
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    isToBePaid:{
        type:DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    },
    isPaidFor:{
        type:DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    },
},{
    freezeTableName: true
});

WorkCards.hasMany(Requirements, {foreignKey: 'workcard_id'});
Requirements.belongsTo(WorkCards, {foreignKey: 'workcard_id'});

Stock.hasMany(Requirements,{
    sourceKey: 'keepingUnit',
    foreignKey: 'keepingUnit'
});

Requirements.belongsTo(Stock,{
    foreignKey: 'keepingUnit',
    targetKey: 'keepingUnit'
});


module.exports = Requirements;