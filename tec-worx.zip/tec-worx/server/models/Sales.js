const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const Employee = require("./Employee");

const Sales = db.define('sales', {
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    totalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    method: {
        type: DataTypes.STRING,
        allowNull: false
    },
    rate: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    newTotalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    paidAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cashier: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

Employee.hasMany(Sales, {
    foreignKey: 'cashier'
});

Sales.belongsTo(Employee, {
    foreignKey: 'cashier'
});


module.exports = Sales;