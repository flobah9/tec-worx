const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const Sales = require("./Sales");
const Stock = require("./Inventory");

const SoldItems = db.define('soldItems', {
    sales_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    product: {
        type: DataTypes.STRING,
        allowNull: false
    },
    keepingUnit: {
        type: DataTypes.STRING,
        allowNull: false
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    price: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    cost: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    freezeTableName: true
});

Sales.hasMany(SoldItems, { foreignKey: 'sales_id' });
SoldItems.belongsTo(Sales, { foreignKey: 'sales_id' });

Stock.hasMany(SoldItems, {
    sourceKey: 'keepingUnit',
    foreignKey: 'keepingUnit'
});

SoldItems.belongsTo(Stock, {
    foreignKey: 'keepingUnit',
    targetKey: 'keepingUnit'
});

module.exports = SoldItems;