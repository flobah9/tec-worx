const { DataTypes } = require('sequelize');
const db = require('../config/Database');
const JobCards = require("./JobCard");
const Employees = require("./Employee");

const WorkCards = db.define('workshop', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    cardNo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    diagnosisResults: {
        type: DataTypes.STRING,
        allowNull: false
    },
    otherRequirements: {
        type: DataTypes.STRING,
        allowNull: true
    },
    otherRequirementsUsed: {
        type: DataTypes.STRING,
        allowNull: true
    },
    estimatedTime: {
        type: DataTypes.STRING,
        allowNull: false
    },
    labourCharge: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    invoice: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    jobdone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    partsUsed: {
        type: DataTypes.STRING,
        allowNull: true,
        get() {
            return this.getDataValue('partsUsed')?.split(';')
        },
        set(val) {
            this.setDataValue('partsUsed', val.join(';'));
        },
    },
    timeTaken: {
        type: DataTypes.STRING,
        allowNull: true
    },
    technician: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

JobCards.hasOne(WorkCards, {
    sourceKey: 'cardNo',
    foreignKey: 'cardNo'
});

WorkCards.belongsTo(JobCards, {
    foreignKey: 'cardNo',
    targetKey: 'cardNo'
});

Employees.hasMany(WorkCards, {
    foreignKey: 'technician'
});

WorkCards.belongsTo(Employees, {
    foreignKey: 'technician'
});

module.exports = WorkCards;
