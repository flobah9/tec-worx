const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const RepairCategory = require("./RepairCategory");

const Manufacturer = db.define('manufacturer', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    repairId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    manufacture: {
        type: DataTypes.STRING,
        allowNull: false
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true
    }
}, {
    freezeTableName: true
});

RepairCategory.hasMany(Manufacturer, {
    foreignKey: 'repairId'
});

Manufacturer.belongsTo(RepairCategory, {
    foreignKey: 'repairId'
});

module.exports = Manufacturer;