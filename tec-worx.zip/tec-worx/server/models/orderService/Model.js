const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const RepairCategory = require("./RepairCategory");
const Manufacturer = require("./Manufacturer");

const DeviceModel = db.define('devicemodel', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    repairId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    manufactureId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    model: {
        type: DataTypes.STRING,
        allowNull: false
    },
    image: {
        type: DataTypes.STRING,
        allowNull: true
    }
}, {
    freezeTableName: true
});

Manufacturer.hasMany(DeviceModel, {
    foreignKey: 'manufactureId'
});

DeviceModel.belongsTo(Manufacturer, {
    foreignKey: 'manufactureId'
});

RepairCategory.hasMany(DeviceModel, {
    foreignKey: 'repairId'
});
DeviceModel.belongsTo(RepairCategory, {
    foreignKey: 'repairId'
});

module.exports = DeviceModel;