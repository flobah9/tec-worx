const { DataTypes } = require("sequelize");
const db = require("../../config/Database");
const OrderService = require("./OrderService");
const Employees = require("../Employee");

const OrderCollection = db.define('ordercollection', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    orderId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    collectedBy: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fullName: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
})

OrderService.hasOne(OrderCollection, {
    sourceKey: 'orderId',
    foreignKey: 'orderId'
});

OrderCollection.belongsTo(OrderService, {
    foreignKey: 'orderId',
    targetKey: 'orderId'
});

Employees.hasMany(OrderCollection, {
    foreignKey: 'user'
});

OrderCollection.belongsTo(Employees, {
    foreignKey: 'user'
});

module.exports = OrderCollection;