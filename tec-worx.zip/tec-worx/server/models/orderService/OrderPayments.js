const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const Employees = require("../Employee");
const OrderService = require("./OrderService");
const Sales = require("../Sales");

const OrderPayments = db.define('orderpayments', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    sales_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    orderId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    totalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    paidAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    user: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

Employees.hasMany(OrderPayments, {
    foreignKey: 'user'
});

OrderPayments.belongsTo(Employees, {
    foreignKey: 'user'
});

Sales.hasMany(OrderPayments, { foreignKey: 'sales_id' });
OrderPayments.belongsTo(Sales, { foreignKey: 'sales_id' });

OrderService.hasMany(OrderPayments, {
    sourceKey: 'orderId',
    foreignKey: 'orderId'
});

OrderPayments.belongsTo(OrderService, {
    foreignKey: 'orderId',
    targetKey: 'orderId'
});

module.exports = OrderPayments;