const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const DeviceModel = require("./Model");
const Customer = require("../Customer");

const OrderService = db.define('orderservice', {
    date: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull: false
    },
    orderId: {
        type: DataTypes.STRING,
        allowNull: true,
        unique: true
    },
    modelId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    bookedDate: {
        type: DataTypes.DATE,
        allowNull: false
    },
    isCollected: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    },
    status: {
        type: DataTypes.STRING,
        allowNull: true
    },
    customerId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
})

DeviceModel.hasMany(OrderService, {
    foreignKey: 'modelId'
});

OrderService.belongsTo(DeviceModel, {
    foreignKey: 'modelId'
});

Customer.hasMany(OrderService, {
    foreignKey: 'customerId'
})

OrderService.belongsTo(Customer, {
    foreignKey: 'customerId'
});

module.exports = OrderService;