const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const OrderService = require("./OrderService");
const ModelProblems = require("./Problem");

const OrderedServices = db.define('orderedservices', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    order_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    problem_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    problem: {
        type: DataTypes.STRING,
        allowNull: false
    },
    repairCost: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    freezeTableName: true
});

OrderService.hasMany(OrderedServices, {
    foreignKey: 'order_id'
});

OrderedServices.belongsTo(OrderService, {
    foreignKey: 'order_id'
});

ModelProblems.hasMany(OrderedServices, {
    foreignKey: 'problem_id'
});
OrderedServices.belongsTo(ModelProblems, {
    foreignKey: 'problem_id'
});

module.exports = OrderedServices;