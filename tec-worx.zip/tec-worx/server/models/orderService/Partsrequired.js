const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const Stock = require("../Inventory");
const WorkOrders = require("./WorkOrder");

const Partsrequired = db.define('partsrequired', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    workorder_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    keepingUnit: {
        type: DataTypes.STRING,
        allowNull: false
    },
    product: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    isToBePaid: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    },
    isPaidFor: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: 0
    }
}, {
    freezeTableName: true
});

Stock.hasMany(Partsrequired, {
    sourceKey: 'keepingUnit',
    foreignKey: 'keepingUnit'
});

Partsrequired.belongsTo(Stock, {
    foreignKey: 'keepingUnit',
    targetKey: 'keepingUnit'
});

WorkOrders.hasMany(Partsrequired, { foreignKey: 'workorder_id' });
Partsrequired.belongsTo(WorkOrders, { foreignKey: 'workorder_id' });

module.exports = Partsrequired;