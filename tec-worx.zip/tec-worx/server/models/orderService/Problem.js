const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const DeviceModel = require("./Model");
const Manufacturer = require("./Manufacturer");
const RepairCategory = require("./RepairCategory");

const ModelProblems = db.define('modelproblem', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    repairId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    manufactureId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    modelId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    problem: {
        type: DataTypes.STRING,
        allowNull: false
    },
    repairCost: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    }
}, {
    freezeTableName: true
});

DeviceModel.hasMany(ModelProblems, {
    foreignKey: 'modelId'
});

ModelProblems.belongsTo(DeviceModel, {
    foreignKey: 'modelId'
});

Manufacturer.hasMany(ModelProblems, {
    foreignKey: 'manufactureId'
});

ModelProblems.belongsTo(Manufacturer, {
    foreignKey: 'manufactureId'
});

RepairCategory.hasMany(ModelProblems, {
    foreignKey: 'repairId'
});
ModelProblems.belongsTo(RepairCategory, {
    foreignKey: 'repairId'
});

module.exports = ModelProblems;