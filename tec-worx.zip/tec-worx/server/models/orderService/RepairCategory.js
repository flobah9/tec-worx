const { DataTypes } = require('sequelize');
const db = require('../../config/Database');

const RepairCategory = db.define('repaircategory', {
    uuid:{
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate:{
            notEmpty: true
        }
    },
    repair:{
        type: DataTypes.STRING,
        allowNull: false
    },
    image:{
        type: DataTypes.STRING,
        allowNull:true
    }
}, {
    freezeTableName: true
});

module.exports = RepairCategory;