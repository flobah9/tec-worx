const { DataTypes } = require('sequelize');
const db = require('../../config/Database');
const Employees = require("../Employee");
const OrderService = require("./OrderService");

const WorkOrders = db.define('orderswork', {
    uuid: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    Date: {
        type: DataTypes.DATE,
        allowNull: true
    },
    orderId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    labourCharge: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: true
    },
    otherParts: {
        type: DataTypes.STRING,
        allowNull: true
    },
    otherPartsUsed: {
        type: DataTypes.STRING,
        allowNull: true
    },
    timeEstimate: {
        type: DataTypes.STRING,
        allowNull: true
    },
    invoice: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    jobdone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    partsUsed: {
        type: DataTypes.STRING,
        allowNull: true,
        get() {
            return this.getDataValue('partsUsed')?.split(';')
        },
        set(val) {
            this.setDataValue('partsUsed', val.join(';'));
        },
    },
    timeTaken: {
        type: DataTypes.STRING,
        allowNull: true
    },
    technician: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
}, {
    freezeTableName: true
});

OrderService.hasOne(WorkOrders, {
    sourceKey: 'orderId',
    foreignKey: 'orderId'
});

WorkOrders.belongsTo(OrderService, {
    foreignKey: 'orderId',
    targetKey: 'orderId'
});

Employees.hasMany(WorkOrders, {
    foreignKey: 'technician'
});

WorkOrders.belongsTo(Employees, {
    foreignKey: 'technician'
});

module.exports = WorkOrders;