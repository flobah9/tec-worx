const express = require("express");
const { verifyUser } = require('../middleware/AuthUser');
const { Login, Me, logOut, changePassword } = require("../controllers/Auth");

const router = express.Router();

router.get('/profile', Me);
router.post('/login', Login);
router.put('/changepass', verifyUser, changePassword)
router.delete('/logout', logOut);

module.exports = router;