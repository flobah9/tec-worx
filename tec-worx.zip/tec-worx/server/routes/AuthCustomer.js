const express = require("express");
const { Login, logOut } = require("../controllers/CustomerAuth");

const router = express.Router();

router.post('/custlogin', Login);
router.delete('/custlogout', logOut);

module.exports = router;