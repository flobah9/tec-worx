const express = require("express");
const { verifyUser } = require("../middleware/AuthUser");
const { uploadImage } = require("../middleware/UploadImage");
const { verifyCustomer } = require("../middleware/AuthCustomer")
const { getAllJobCards, countJobCards, addNewJobCard, CancelJobCard, getJobCardByCardNo, getJobCardByCustomerID, getAllJobCardsToDiagnose, countJobCardsCancelled, countJobCardsDiagonised, countJobCardsRepair, RepairJobCard, RecordMyJobCard, updateJobCard } = require("../controllers/JobCard");
const { AddCollectionForm } = require("../controllers/Collection");

const router = express.Router();

router.get('/cards', verifyUser, getAllJobCards);
router.get('/dcards', verifyUser, getAllJobCardsToDiagnose);
router.get('/card/:cardNo', verifyUser, getJobCardByCardNo);
router.get('/jobcard/:customerID', getJobCardByCustomerID);
router.post('/collect', verifyUser, AddCollectionForm);
router.post('/cards', verifyUser, uploadImage, addNewJobCard);
router.patch('/jobcard/:id', verifyUser, CancelJobCard);
router.patch('/jobcards/:id', verifyUser, RepairJobCard);
router.patch('/cards/:id', verifyUser, uploadImage, updateJobCard);
router.get('/cardcount', verifyUser, countJobCards);
router.get('/cardDiagonised', verifyUser, countJobCardsDiagonised);
router.get('/cardCancel', verifyUser, countJobCardsCancelled);
router.get('/cardRepair', verifyUser, countJobCardsRepair);

//customer post
router.post('/myrecord', verifyCustomer, RecordMyJobCard);

module.exports = router;
