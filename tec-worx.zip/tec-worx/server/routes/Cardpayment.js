const express = require("express");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");
const { PayForCard, PayDiagnosisFee, FindJobCardPayment, UpdatePayForCard, FindCustomerCardPayments, FindAllCardPayments, FindCustomerSalesPayments } = require("../controllers/CardPayments");
const { verifyCustomer } = require('../middleware/AuthCustomer');

const router = express.Router();

router.get('/payfee/:cardNo', verifyUser, FindJobCardPayment);
router.get('/payment', verifyUser, adminOnly, FindAllCardPayments);
router.post('/payment', verifyUser, PayForCard);
router.get('/mycardpayment', verifyCustomer, FindCustomerCardPayments)
router.get('/mysalespayment', verifyCustomer, FindCustomerSalesPayments)
//router.post('/payfee', verifyUser, PayDiagnosisFee);
router.post('/cardfees', verifyUser, UpdatePayForCard);

module.exports = router;