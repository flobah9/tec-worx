const express = require("express");
const { getCategory, getCategoryById, addNewCategory, updateCategory, deleteCategory, countCategory } = require("../controllers/Category");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");

const router = express.Router();

router.get('/category', verifyUser, getCategory);
router.get('/category/:id', verifyUser, getCategoryById);
router.get('/countcategory', verifyUser, countCategory);
router.post('/category', verifyUser, adminOnly, addNewCategory);
router.patch('/category/:id', verifyUser, adminOnly, updateCategory);
router.delete('/category/:id', verifyUser, adminOnly, deleteCategory);

module.exports = router;