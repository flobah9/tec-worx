const express = require("express");
const { getAllCustomers, getCustomerByCustomerID, addNewCustomer, updateCustomer, deleteCustomer, countCustomers, searchPhone } = require("../controllers/Customer");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");

const router = express.Router();

router.get('/customer', verifyUser, getAllCustomers);
router.get('/customer/:id', verifyUser, getCustomerByCustomerID);
router.get('/countCustomer', verifyUser, countCustomers);
router.get('/cphone/:phone', verifyUser, searchPhone)
router.post('/customer', addNewCustomer);
router.patch('/customer/:id', verifyUser, updateCustomer);
router.delete('/customer/:id', verifyUser, adminOnly, deleteCustomer);

module.exports = router;