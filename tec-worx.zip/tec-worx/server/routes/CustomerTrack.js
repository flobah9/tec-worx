const express = require("express");
const { CustomerRegistration, GetAllJobCards, CountMyJobCards, GetCustomerProfile } = require("../controllers/CustomerRegistration");
const { verifyCustomer } = require("../middleware/AuthCustomer");

const router = express.Router();

router.get('/mycards', verifyCustomer, GetAllJobCards);
router.get('/countmycards', verifyCustomer, CountMyJobCards);
router.get('/custprofile', verifyCustomer, GetCustomerProfile);
router.post('/register', CustomerRegistration);

module.exports = router;