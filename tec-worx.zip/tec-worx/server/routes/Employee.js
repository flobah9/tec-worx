const express = require("express");
const { getAllEmployees, addNewEmployee, updateEmployee, deleteEmployee, getEmployeeById, signUpEmployee, getAllTechnicians, countEmployee } = require("../controllers/Employee");
const { verifyUser, adminOnly, TechAdminOnly } = require("../middleware/AuthUser");

const router = express.Router();

router.get('/employee', verifyUser, adminOnly, getAllEmployees);
router.get('/employee/:id', verifyUser, adminOnly, getEmployeeById);
router.get('/countEmp', verifyUser, countEmployee);
router.get('/technicians', verifyUser, TechAdminOnly, getAllTechnicians);
router.post('/employee', verifyUser, adminOnly,addNewEmployee);
router.patch('/employee/:id', verifyUser, adminOnly, updateEmployee);
router.patch('/newemployee', signUpEmployee)
router.delete('/employee/:id', verifyUser, adminOnly, deleteEmployee);

module.exports = router;