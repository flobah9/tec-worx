const express = require("express");
const { getAllMake, addNewMake, updateMake, deleteMake, selectMake, countMake } = require("../controllers/Make");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");

const router = express.Router();

router.get('/make', verifyUser, getAllMake);
router.get('/countmake', verifyUser, countMake)
router.get('/make/:catId', verifyUser, selectMake);
router.post('/make', verifyUser, adminOnly, addNewMake);
router.patch('/make/:id', verifyUser, adminOnly, updateMake);
router.delete('/make/:id', verifyUser, adminOnly, deleteMake);

module.exports = router;