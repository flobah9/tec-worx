const express = require("express");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");
const { AddNewPaymentMethod, UpdatePaymentMethod, GetAllPaymentMethods, GetAllActivePaymentMethods } = require("../controllers/PaymentMethod");

const router = express.Router();

router.get('/method', verifyUser, GetAllActivePaymentMethods);
router.get('/methods', verifyUser, adminOnly, GetAllPaymentMethods);
router.post('/method', verifyUser, adminOnly, AddNewPaymentMethod);
router.patch('/method/:id', verifyUser, adminOnly, UpdatePaymentMethod);

module.exports = router;