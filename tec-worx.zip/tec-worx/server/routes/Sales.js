const express = require('express');
const { verifyUser, adminOnly } = require("../middleware/AuthUser");
const { GetAllSales, PointOfSale, GetProductCount, GetTotalSales } = require('../controllers/Sales');

const router = express.Router();

router.post('/pos', verifyUser, PointOfSale);
router.get('/pos', verifyUser, adminOnly, GetAllSales);
router.get('/sold', verifyUser, GetProductCount);
router.get('/sales', verifyUser, GetTotalSales);

module.exports = router;