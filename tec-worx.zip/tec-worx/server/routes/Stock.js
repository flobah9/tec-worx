const express = require("express");
const { getAllProducts, addNewProduct, updateProduct, deleteProduct, getProductById, getProductBySKU, countProducts, GetLowStockItems } = require("../controllers/Inventory");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");

const router = express.Router();

router.get('/products', verifyUser, getAllProducts);
router.get('/product', verifyUser, adminOnly, GetLowStockItems);
router.get('/countproduct', verifyUser, countProducts);
router.get('/products/:id', verifyUser, getProductById);
router.get('/product/:keepingUnit', verifyUser, getProductBySKU);
router.post('/products', verifyUser, adminOnly, addNewProduct);
router.patch('/products/:id', verifyUser, adminOnly, updateProduct);
router.delete('/products/:id', verifyUser, adminOnly, deleteProduct);

module.exports = router;