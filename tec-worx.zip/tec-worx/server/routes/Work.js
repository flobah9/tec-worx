const express = require("express");
const { verifyUser, adminOnly } = require("../middleware/AuthUser");
const { getAllWorkCards, getWorkCardByCardNo, updateWorkCard, addNewWorkCard, countWorkCards, getWorkCardForRepair, viewMyWork, TechnicianByNumber, countMyWorkCard } = require("../controllers/WorkCard");

const router = express.Router();

router.get('/workcard', verifyUser, getAllWorkCards);
router.get('/countwork', verifyUser, adminOnly, TechnicianByNumber);
router.get('/workcards', verifyUser, getWorkCardForRepair);
router.get('/workcardss', verifyUser, viewMyWork);
router.get('/workcard/:cardNo', verifyUser, getWorkCardByCardNo);
router.patch('/workcard/:id', verifyUser, updateWorkCard);
router.post('/workcard', verifyUser, addNewWorkCard);
router.get('/workcardCount', verifyUser, countWorkCards);
router.get('/myworkcards', verifyUser, countMyWorkCard);

module.exports = router;