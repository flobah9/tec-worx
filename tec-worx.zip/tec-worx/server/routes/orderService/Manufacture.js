const express = require('express');
const { addNewManufacturer, updateManufacturer, selectManufacturerByRepair, getAllManufacturer, GetManufactureById } = require('../../controllers/orderService/Manufacturer');
const { TechAdminOnly, verifyUser } = require('../../middleware/AuthUser');
const { uploadManufactureImage } = require('../../middleware/orderService/UploadManufactureImage');
const { verifyCustomer } = require('../../middleware/AuthCustomer');

const router = express.Router();

router.get('/manufacture/:repairId', verifyCustomer, selectManufacturerByRepair);
router.get('/allmanufacture/:repairId', verifyUser, selectManufacturerByRepair);
router.get('/allmanufacture', verifyUser, getAllManufacturer);
router.get('/manufacturer/:id', verifyUser, GetManufactureById);
router.post('/manufacture', verifyUser, TechAdminOnly, uploadManufactureImage, addNewManufacturer);
router.patch('/manufacture/:id', verifyUser, TechAdminOnly, updateManufacturer);

module.exports = router;