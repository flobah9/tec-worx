const express = require('express');
const { TechAdminOnly, verifyUser } = require('../../middleware/AuthUser');
const { uploadModelImage } = require('../../middleware/orderService/UploadModelImage')
const { verifyCustomer } = require('../../middleware/AuthCustomer');
const { addNewDeviceModel, getAllDeviceModel, updateDeviceModel, selectModelByManufacture } = require('../../controllers/orderService/Model');

const router = express.Router();

router.get('/model', verifyUser, getAllDeviceModel);
router.get('/modelz/:manufactureId', verifyCustomer, selectModelByManufacture)
router.get('/model/:manufactureId', verifyUser, selectModelByManufacture)
router.post('/model', verifyUser, TechAdminOnly, uploadModelImage, addNewDeviceModel)
router.patch('/model/:id', verifyUser, TechAdminOnly, updateDeviceModel);

module.exports = router;