const express = require('express');
const { verifyUser, TechAdminOnly } = require('../../middleware/AuthUser');
const { verifyCustomer } = require('../../middleware/AuthCustomer');
const { OrderAService, OrderServiceForCustomer, RepairOrder, GetAllOrderedServices, CountMyJobServices, CountOrders, GetOrderServiceByCustomerId, CancelAppointment, RescheduleAppointment, GetOrderByOrderNo } = require('../../controllers/orderService/OrderService');

const router = express.Router();

router.get('/service', verifyUser, GetAllOrderedServices)
router.get('/services', verifyCustomer, CountMyJobServices)
router.get('/orderSum', verifyUser, CountOrders)
router.get('/myservice', verifyCustomer, GetOrderServiceByCustomerId)
router.get('/getorder/:orderId', verifyUser, GetOrderByOrderNo);
router.post('/service', verifyCustomer, OrderAService)
router.post('/orderfor', verifyUser, OrderServiceForCustomer)
router.patch('/orderfor/:id', verifyUser, RepairOrder)
router.patch('/service/:id', verifyCustomer, CancelAppointment)
router.patch('/reservice/:id', verifyUser, RescheduleAppointment)

module.exports = router;