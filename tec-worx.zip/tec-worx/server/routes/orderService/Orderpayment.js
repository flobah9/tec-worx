const express = require('express');
const { verifyUser, adminOnly } = require('../../middleware/AuthUser');
const { verifyCustomer } = require('../../middleware/AuthCustomer');
const { FindOrderPayment, PayForOrder, UpdatePayForOrder, FindAllOrderPayments, FindCustomerOrderPayments } = require('../../controllers/orderService/OrderPayments');

const router = express.Router();

router.get('/orderfee/:orderId', verifyUser, FindOrderPayment);
router.get('/myorderpayment', verifyCustomer, FindCustomerOrderPayments)
router.get('/payorderpayment', verifyUser, adminOnly, FindAllOrderPayments);
router.post('/payorderpayment', verifyUser, PayForOrder);
router.post('/updateorderpayment', verifyUser, UpdatePayForOrder);

module.exports = router;