const express = require('express');
const { verifyUser, TechAdminOnly } = require('../../middleware/AuthUser');
const { verifyCustomer } = require('../../middleware/AuthCustomer');
const { selectProblemByDeviceModel, addNewDeviceModelProblem, updateDeviceModelProblem, getAllDeviceModelProblems } = require('../../controllers/orderService/Problem');

const router = express.Router();

router.get('/problem/:modelId', verifyCustomer, selectProblemByDeviceModel)
router.get('/problems/:modelId', verifyUser, selectProblemByDeviceModel)
router.get('/problem', verifyUser, getAllDeviceModelProblems)
router.post('/problem', verifyUser, TechAdminOnly, function (req, res) { addNewDeviceModelProblem })
router.patch('/problem/:id', verifyUser, TechAdminOnly, updateDeviceModelProblem)

module.exports = router;