const express = require('express');
const { getRepairCategory, addNewRepairCategory, updateRepairCategory, getRepairCategoryById } = require('../../controllers/orderService/RepairCategory');
const { TechAdminOnly, verifyUser } = require('../../middleware/AuthUser');
const { uploadRepairImage } = require('../../middleware/orderService/UploadRepairImage')
const { verifyCustomer } = require('../../middleware/AuthCustomer');

const router = express.Router();
router.get('/repairCat', verifyCustomer, getRepairCategory)
router.get('/repair', verifyUser, getRepairCategory);
router.get('/repairs/:id', verifyUser, getRepairCategoryById);
router.post('/repair', verifyUser, TechAdminOnly, uploadRepairImage, addNewRepairCategory);
router.patch('/repair/:id', verifyUser, TechAdminOnly, updateRepairCategory);

module.exports = router;
