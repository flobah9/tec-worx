const express = require("express");
const { verifyUser, TechAdminOnly } = require("../../middleware/AuthUser");
const { AssingTechnician, WorkOnTheOrder, GetMyWorkingOrders, updateWorkOrder, countMyWorkAssign } = require("../../controllers/orderService/WorkOder");
const { AddOrderCollectionRecord } = require("../../controllers/orderService/OrderCollection");

const router = express.Router();

router.post('/assign', verifyUser, TechAdminOnly, function (req, res) { AssingTechnician });
router.post('/ordercollect', verifyUser, function (req, res) { AddOrderCollectionRecord });
router.patch('/assigned/:id', verifyUser, WorkOnTheOrder);
router.patch('/assign/:id', verifyUser, updateWorkOrder);
router.get('/assigned', verifyUser, GetMyWorkingOrders);
router.get('/countassigned', verifyUser, countMyWorkAssign);

module.exports = router;
