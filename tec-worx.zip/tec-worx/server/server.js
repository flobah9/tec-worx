const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const path = require("path");
var session = require("express-session");
const SequelizeStore = require("connect-session-sequelize");
const db = require("./config/Database");
const Category = require("./routes/Category");
const Employee = require("./routes/Employee");
const Make = require("./routes/Make");
const Stock = require("./routes/Stock");
const Auth = require("./routes/Auth");
const Customer = require("./routes/Customer");
const Card = require("./routes/Card");
const Work = require("./routes/Work");
const AuthCustomer = require("./routes/AuthCustomer");
const CustomerTrack = require("./routes/CustomerTrack");
const Sales = require("./routes/Sales");
const RepairCategory = require("./routes/orderService/RepairCategory");
const Manufacture = require("./routes/orderService/Manufacture");
const Model = require("./routes/orderService/Model");
const Problem = require("./routes/orderService/Problem");
const OrderService = require("./routes/orderService/OrderService");
const WorkOrder = require("./routes/orderService/WorkOrder");
const Payment = require("./routes/PaymentMethod");
const Cardpayment = require("./routes/Cardpayment");
const Orderpayment = require("./routes/orderService/Orderpayment");

// (async()=>{
// await db.sync();
// })();

dotenv.config();
const app = express();

const sessionStore = SequelizeStore(session.Store);
const store = new sessionStore({
  db: db,
});

app.use(
  session({
    secret: process.env.SESS_SECRET,
    resave: false,
    saveUninitialized: true,
    store: store,
    cookie: {
      secure: false,
    },
  })
);

// app.use(express.static(path.join(__dirname + '/public')));

app.use(
  cors({
    origin: "http://localhost:3000", // use your actual domain name (or localhost), using * is not recommended
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
    allowedHeaders: [
      "Content-Type",
      "Origin",
      "X-Requested-With",
      "Accept",
      "x-client-key",
      "x-client-token",
      "x-client-secret",
      "Authorization",
    ],
    credentials: true,
  })
);

// app.get('*', (req, res) => {
//     res.sendFile(path.join(__dirname, '/public', 'index.html'));
// });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/Images", express.static("./Images"));
app.use(Category);
app.use(Stock);
app.use(Make);
app.use(Employee);
app.use(Auth);
app.use(Customer);
app.use(Card);
app.use(Work);
app.use(AuthCustomer);
app.use(CustomerTrack);
app.use(Sales);
app.use(RepairCategory);
app.use(Model);
app.use(Manufacture);
app.use(Problem);
app.use(OrderService);
app.use(WorkOrder);
app.use(Payment);
app.use(Cardpayment);
app.use(Orderpayment);

app.listen(process.env.APP_PORT, () => {
  console.log("Server up and running...");
});
