-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 04, 2024 at 12:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tecworx`
--

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `catId` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `uuid`, `catId`, `make`, `createdAt`, `updatedAt`) VALUES
(1, 'cdab8e0f-a0d1-474f-8ad3-479e96970d47', 1, 'Hp', '2024-04-03 21:25:05', '2024-04-03 21:25:05'),
(2, 'c768bfbd-0c47-4e3b-ade6-0265e952c353', 1, 'Dell', '2024-04-03 21:25:17', '2024-04-03 21:25:17'),
(3, 'd3082f00-71d1-475e-805e-eaa6d7d849c8', 2, 'Lenovo', '2024-04-03 21:25:34', '2024-04-03 21:25:34'),
(4, '5878ab39-7e3f-4a61-a4e8-28af0ee924dc', 3, 'Canon', '2024-04-03 21:25:50', '2024-04-03 21:25:50'),
(5, 'aec6ad5c-c547-4f6e-b810-af7fcc1d25ff', 4, 'Crucial', '2024-04-03 21:59:00', '2024-04-03 21:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `cardpayments`
--

CREATE TABLE `cardpayments` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `sales_id` int(11) DEFAULT NULL,
  `cardNo` varchar(255) NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `paidAmount` decimal(10,2) NOT NULL,
  `user` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `card_id`
--

CREATE TABLE `card_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `card_id`
--

INSERT INTO `card_id` (`id`) VALUES
(1),
(2);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `category` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `uuid`, `category`, `description`, `createdAt`, `updatedAt`) VALUES
(1, '0315aac4-1699-49cf-8c35-f23908a46d5d', 'Laptop', 'this includes palmtops', '2024-04-03 21:23:39', '2024-04-03 21:23:39'),
(2, '9d5511e5-95e5-4c18-bb23-628a3a381a55', 'Desktop', 'big and small cpu\'s', '2024-04-03 21:24:30', '2024-04-03 21:24:30'),
(3, '1cbc5795-ec80-4f63-b43e-09bce8ba1986', 'Printers', 'all brands included', '2024-04-03 21:24:54', '2024-04-03 21:24:54'),
(4, '59e8b5f7-2248-47b1-8c14-4a324b796995', 'Ram', 'for laptops and desktops', '2024-04-03 21:58:43', '2024-04-03 21:58:43');

-- --------------------------------------------------------

--
-- Table structure for table `collection`
--

CREATE TABLE `collection` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `customerID` varchar(255) NOT NULL,
  `cardNo` varchar(255) NOT NULL,
  `collectedBy` varchar(255) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `customerID` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contactPerson` varchar(255) DEFAULT NULL,
  `contactPersonCell` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `uuid`, `customerID`, `fullName`, `phone`, `email`, `address`, `contactPerson`, `contactPersonCell`, `role`, `createdAt`, `updatedAt`) VALUES
(1, 'fb187323-dee6-4a38-aeaf-71e5f627150a', 'CST0001', 'Nelson Nero', '263717769970', 'takuganda@mail.com', '47 Castens Belvedere', 'the traveller', '0776419969', 'Individual', '2024-04-03 22:21:29', '2024-04-03 22:21:29'),
(2, '36d53c3e-1922-40b6-9111-b4182bf9f53d', 'CST0002', 'Rukudzo Yantoe', '263771457122', 'rukuejanhi@gmail.com', 'Bindura', 'Robert', '0776419969', 'Individual', '2024-04-03 22:31:43', '2024-04-03 22:31:43');

--
-- Triggers `customers`
--
DELIMITER $$
CREATE TRIGGER `getCustId` BEFORE INSERT ON `customers` FOR EACH ROW BEGIN
	INSERT INTO customer_id VALUES (NULL);
    SET NEW.customerID =  CONCAT("CST",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customer_id`
--

CREATE TABLE `customer_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_id`
--

INSERT INTO `customer_id` (`id`) VALUES
(1),
(2);

-- --------------------------------------------------------

--
-- Table structure for table `devicemodel`
--

CREATE TABLE `devicemodel` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `repairId` int(11) NOT NULL,
  `manufactureId` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `devicemodel`
--

INSERT INTO `devicemodel` (`id`, `uuid`, `repairId`, `manufactureId`, `model`, `image`, `createdAt`, `updatedAt`) VALUES
(1, '506b4bcf-9dc7-470e-a59c-e2561848c13e', 1, 1, 'Probook 4530', 'Images/Model/1712222129216.jpeg', '2024-04-04 11:15:29', '2024-04-04 11:15:29'),
(2, 'a1f67860-99e3-4a7d-a35b-0c01dcf4c6a6', 1, 1, 'Probook 650 G1', 'Images/Model/1712222155149.jpg', '2024-04-04 11:15:55', '2024-04-04 11:15:55'),
(3, '8a3346a2-1b0d-4dc6-b766-9c1767477d5f', 1, 5, 'Latitude 14', 'Images/Model/1712222178670.jpeg', '2024-04-04 11:16:18', '2024-04-04 11:16:18'),
(4, '4cfb15c4-4ac9-408f-a690-5dc0786898b9', 1, 5, 'Inspiron 15.6', 'Images/Model/1712222205188.jpg', '2024-04-04 11:16:45', '2024-04-04 11:16:45'),
(5, 'c2c1df2b-3b51-454d-9c6a-4216e119f3f2', 1, 7, 'Galaxy Book 3 360', 'Images/Model/1712222230881.jpeg', '2024-04-04 11:17:10', '2024-04-04 11:17:10'),
(6, '94b28df2-b727-4db0-89d4-f0c0cbfee78a', 1, 7, 'Galaxy Book Pro 360', 'Images/Model/1712222270780.jpg', '2024-04-04 11:17:50', '2024-04-04 11:17:50'),
(7, '52558a5b-fa83-41bc-ba6d-709dc7b154bb', 2, 2, 'Optiplex', 'Images/Model/1712222405127.jpeg', '2024-04-04 11:20:05', '2024-04-04 11:20:05'),
(8, '4ca229f4-4b4b-4d4b-ba36-497c05beee3b', 3, 4, 'Iphone X', 'Images/Model/1712222480447.jpeg', '2024-04-04 11:21:20', '2024-04-04 11:21:20'),
(9, 'ac2fc3dd-4736-4d5c-b6f3-2330ef9a77ee', 3, 4, 'Iphone Xs', 'Images/Model/1712222503765.jpeg', '2024-04-04 11:21:43', '2024-04-04 11:21:43');

-- --------------------------------------------------------

--
-- Table structure for table `diagnosisFee`
--

CREATE TABLE `diagnosisFee` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `cardNo` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(255) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `finalAmount` decimal(10,2) NOT NULL,
  `user` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `uuid`, `firstName`, `lastName`, `phone`, `address`, `email`, `userName`, `password`, `role`, `createdAt`, `updatedAt`) VALUES
(1, '81a8152a-dc80-442f-803d-375d1fb3a24a', 'Floby', 'Bebe', '263784711808', 'Budaz', 'manflobah9@gmail.com', 'flobah9', '$2b$10$l2LmFp/z57rPGGuE/SC27u81QtutFrTfM2MMK7w.Avb5eEbzl6FgW', 'Admin', '2024-04-02 17:42:23', '2024-04-02 23:02:00'),
(2, 'f212ab95-3276-46a4-8661-2069776d9212', 'Panashe', 'Bhima', '263715750630', '39 Lawley Belvedere', 'Ephraimmatashu29@gmail.com', 'Bhima', '$2b$10$/kNydWTFvQcfN92Oqf11G.zLkrNdXDofDNPmKVJicusX5xIOky5k2', 'User', '2024-04-03 21:22:24', '2024-04-03 22:16:28'),
(3, 'b13b2e1b-33f9-4649-8cbb-c810156362c1', 'Bee', 'Jena', '263787093603', 'Nyamapanda', 'michaelthulani469@gmail.com', 'Thulani', '$2b$10$DF6/1d05oyY5uKBPngEhlOCTiSKvGbdNZf39Ggbq5XLalxwmKrOlK', 'Technician', '2024-04-03 22:08:06', '2024-04-04 11:50:54'),
(4, '901e6f9e-d523-4afc-a252-176a00e67628', 'Big', 'Baby', '263713321191', 'Belvedere', 'nelsonnyariri@gmail.com', 'BigNero', '$2b$10$PkNWYcPC79uaNPffPpXP0.PMVRugFOTD/bntLvjGP6ohbEmloIr/O', 'Tech-Admin', '2024-04-03 22:12:17', '2024-04-03 22:34:35');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `catId` int(11) NOT NULL,
  `makeId` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keepingUnit` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(10) UNSIGNED ZEROFILL NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `uuid`, `catId`, `makeId`, `product`, `description`, `keepingUnit`, `price`, `quantity`, `createdAt`, `updatedAt`) VALUES
(1, 'fcd00bcc-5ce7-4ad5-bf36-349e8d45c3b8', 2, 3, 'ThinkCentre Neo 50s Gen 4 (Intel) SFF', 'Powerful—up to 13th Gen Intel® Core™ processing, Loads of memory; optional HDD-SSD hybrid storage', 'PRD0001', 598.00, 0000000029, '2024-04-03 21:49:45', '2024-04-03 23:31:18'),
(2, '373b4a2c-0d2a-4e42-aaff-170da8860eea', 3, 4, 'PIXMA G2010', 'Print Speed (A4, ISO): up to 8.8 / 5 ipm (mono/colour), USB 2.0', 'PRD0002', 202.00, 0000000026, '2024-04-03 21:52:45', '2024-04-04 10:00:58'),
(3, '2aa79f43-4551-47cb-ad2f-560c8ab1a11f', 1, 2, 'Inspiron 3000 Laptop', '5.6\" FHD Display, AMD Ryzen 3 3250U Processor, AMD Radeon Vega 3 Graphics, 8GB RAM, 128GB SSD', 'PRD0003', 650.00, 0000000022, '2024-04-03 21:56:25', '2024-04-04 11:56:26'),
(4, 'cb3fb5d1-5ac5-4276-89bd-4388f3ba44e9', 4, 5, '16GB DDR4 3200 MHz ', 'Heat dissipation and sleek style in a low-profile, aluminum heat spreade', 'PRD0004', 40.00, 0000000033, '2024-04-03 22:03:21', '2024-04-03 23:31:18'),
(5, '9cb94571-4a28-4f17-89cd-efe063145be1', 4, 5, '8GB DDR4 3200 MHz SO-DIMM', 'Heat dissipation and sleek style in a low-profile, aluminum heat spreade', 'PRD0005', 25.00, 0000000025, '2024-04-03 22:04:33', '2024-04-04 11:56:26');

--
-- Triggers `inventory`
--
DELIMITER $$
CREATE TRIGGER `getSKU` BEFORE INSERT ON `inventory` FOR EACH ROW BEGIN
	INSERT INTO sku_id VALUES (NULL);
    SET NEW.keepingUnit =  CONCAT("PRD",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `jobcards`
--

CREATE TABLE `jobcards` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `cardNo` varchar(255) DEFAULT NULL,
  `date` datetime NOT NULL,
  `customerID` varchar(255) NOT NULL,
  `catId` int(11) NOT NULL,
  `makeId` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `serialNo` varchar(255) NOT NULL,
  `problemDesc` varchar(255) NOT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `isCollected` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobcards`
--

INSERT INTO `jobcards` (`id`, `uuid`, `cardNo`, `date`, `customerID`, `catId`, `makeId`, `model`, `serialNo`, `problemDesc`, `comments`, `image`, `status`, `isCollected`, `createdAt`, `updatedAt`) VALUES
(1, '67e0f8e6-4e20-47fe-a96f-81cc4cd90f34', 'TWX0001', '2024-04-17 12:00:00', 'CST0001', 1, 1, 'probook 4530s', 'jpa2075gnf', 'Lcd ', 'good as new', 'Images/Job/1712180152425.jpeg', NULL, 0, '2024-04-03 23:35:52', '2024-04-03 23:35:52'),
(2, 'a66cdde3-ff2e-46b8-bfa1-06d4769c5eae', 'TWX0002', '2024-04-23 12:30:00', 'CST0001', 1, 1, 'notebook', 'asfwr21456ygf', 'super slow', 'missing few screws', NULL, 'Diagonized', 0, '2024-04-04 11:54:58', '2024-04-04 11:57:42');

--
-- Triggers `jobcards`
--
DELIMITER $$
CREATE TRIGGER `getCardId` BEFORE INSERT ON `jobcards` FOR EACH ROW BEGIN
	INSERT INTO card_id VALUES (NULL);
    SET NEW.cardNo =  CONCAT("TWX",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `manufacturer`
--

CREATE TABLE `manufacturer` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `repairId` int(11) NOT NULL,
  `manufacture` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `manufacturer`
--

INSERT INTO `manufacturer` (`id`, `uuid`, `repairId`, `manufacture`, `image`, `createdAt`, `updatedAt`) VALUES
(1, 'd5cf679f-b0f7-4115-bc3f-a86ad0100f2c', 1, 'Hp', 'Images/Manufacture/1712179544936.png', '2024-04-03 23:25:45', '2024-04-03 23:25:45'),
(2, 'f5ac2608-d65e-4d01-9725-767a74122593', 2, 'Dell', 'Images/Manufacture/1712179564513.png', '2024-04-03 23:26:04', '2024-04-03 23:26:04'),
(3, '3c2055c9-56bf-4b59-ab5b-ac0094b3c63d', 4, 'Canon', 'Images/Manufacture/1712179589551.jpg', '2024-04-03 23:26:29', '2024-04-03 23:26:29'),
(4, '42db49b1-f00a-456f-91ee-5e31e10f337a', 3, 'Apple', 'Images/Manufacture/1712179615560.png', '2024-04-03 23:26:55', '2024-04-03 23:26:55'),
(5, '8a6a480d-1303-4584-a816-9510a4e8552c', 1, 'Dell', 'Images/Manufacture/1712179634325.png', '2024-04-03 23:27:14', '2024-04-03 23:27:14'),
(6, '537fdbb1-1836-46b6-937f-c5f3ee829f96', 1, 'Lenovo', 'Images/Manufacture/1712179652887.png', '2024-04-03 23:27:32', '2024-04-03 23:27:32'),
(7, 'ecd0de37-1be7-4867-9324-1945e801d92b', 1, 'Samsung', 'Images/Manufacture/1712179668142.png', '2024-04-03 23:27:48', '2024-04-03 23:27:48'),
(8, '38f6af0a-09a4-45d0-8415-eed785a2321c', 2, 'Hp', 'Images/Manufacture/1712179683579.png', '2024-04-03 23:28:03', '2024-04-03 23:28:03'),
(9, '9d75290a-5bdd-4c9f-b753-4d21e5bfa5df', 2, 'Lenovo', 'Images/Manufacture/1712179699318.png', '2024-04-03 23:28:19', '2024-04-03 23:28:19'),
(10, '7acc4a65-003e-4640-a56c-6744c340f628', 3, 'Nokia', 'Images/Manufacture/1712179719998.png', '2024-04-03 23:28:40', '2024-04-03 23:28:40'),
(11, '83a21584-4ac7-4cb0-9798-6b4300e8569c', 3, 'Samsung', 'Images/Manufacture/1712179738357.png', '2024-04-03 23:28:58', '2024-04-03 23:28:58');

-- --------------------------------------------------------

--
-- Table structure for table `modelproblem`
--

CREATE TABLE `modelproblem` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `repairId` int(11) NOT NULL,
  `manufactureId` int(11) NOT NULL,
  `modelId` int(11) NOT NULL,
  `problem` varchar(255) NOT NULL,
  `repairCost` decimal(10,2) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ordercollection`
--

CREATE TABLE `ordercollection` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `orderId` varchar(255) NOT NULL,
  `collectedBy` varchar(255) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderedservices`
--

CREATE TABLE `orderedservices` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_id` int(11) NOT NULL,
  `problem_id` int(11) NOT NULL,
  `problem` varchar(255) NOT NULL,
  `repairCost` decimal(10,2) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderpayments`
--

CREATE TABLE `orderpayments` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `sales_id` int(11) DEFAULT NULL,
  `orderId` varchar(255) NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `paidAmount` decimal(10,2) NOT NULL,
  `user` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderservice`
--

CREATE TABLE `orderservice` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `orderId` varchar(255) DEFAULT NULL,
  `modelId` int(11) NOT NULL,
  `bookedDate` datetime NOT NULL,
  `isCollected` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(255) DEFAULT NULL,
  `customerId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `orderservice`
--
DELIMITER $$
CREATE TRIGGER `getOrder` BEFORE INSERT ON `orderservice` FOR EACH ROW BEGIN
	INSERT INTO orderserv_id VALUES (NULL);
    SET NEW.orderId =  CONCAT("ORT",LPAD(LAST_INSERT_ID(),4,"0"));
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orderserv_id`
--

CREATE TABLE `orderserv_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orderswork`
--

CREATE TABLE `orderswork` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Date` datetime DEFAULT NULL,
  `orderId` varchar(255) NOT NULL,
  `labourCharge` decimal(10,2) DEFAULT NULL,
  `otherParts` varchar(255) DEFAULT NULL,
  `otherPartsUsed` varchar(255) DEFAULT NULL,
  `timeEstimate` varchar(255) DEFAULT NULL,
  `invoice` varchar(255) DEFAULT NULL,
  `jobdone` varchar(255) DEFAULT NULL,
  `partsUsed` varchar(255) DEFAULT NULL,
  `timeTaken` varchar(255) DEFAULT NULL,
  `technician` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `partsrequired`
--

CREATE TABLE `partsrequired` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workorder_id` int(11) NOT NULL,
  `keepingUnit` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `isToBePaid` tinyint(1) NOT NULL DEFAULT 0,
  `isPaidFor` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `paymentmethod`
--

CREATE TABLE `paymentmethod` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `method` varchar(255) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `isActive` tinyint(1) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentmethod`
--

INSERT INTO `paymentmethod` (`id`, `uuid`, `method`, `rate`, `isActive`, `createdAt`, `updatedAt`) VALUES
(1, 'fa92e807-1270-4436-9099-e54b18529a54', 'USD Cash', 1.00, 1, '2024-04-03 22:22:47', '2024-04-03 22:22:47'),
(2, 'b2030d02-936a-4f89-9901-4b763ff4a11f', 'ZWL', 29000.00, 1, '2024-04-03 22:23:03', '2024-04-03 22:23:03'),
(3, '3cf51742-e41b-4312-8e7b-dd51cb8f1ec5', 'USD Nostro', 1.20, 1, '2024-04-03 22:23:21', '2024-04-03 22:23:21'),
(4, '4f3f78b3-d85b-4ddb-879a-757b98cbd66f', 'Rands', 10.00, 1, '2024-04-03 22:23:33', '2024-04-03 22:23:33');

-- --------------------------------------------------------

--
-- Table structure for table `repaircategory`
--

CREATE TABLE `repaircategory` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `repair` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repaircategory`
--

INSERT INTO `repaircategory` (`id`, `uuid`, `repair`, `image`, `createdAt`, `updatedAt`) VALUES
(1, '0d426a01-c3d4-4f6b-a3bd-64bc650774a9', 'Laptop', 'Images/Repair/1712176695857.jpeg', '2024-04-03 22:38:15', '2024-04-03 22:38:15'),
(2, 'e327bbba-6dfa-4b61-b7d9-97b33b94e843', 'Desktop', 'Images/Repair/1712179478635.png', '2024-04-03 23:24:38', '2024-04-03 23:24:38'),
(3, '2016d4f9-712e-49bf-8d1d-93acf73bc927', 'Phone', 'Images/Repair/1712179500517.jpg', '2024-04-03 23:25:00', '2024-04-03 23:25:00'),
(4, 'b2ded77d-24c5-43f3-8928-ec6ada8cf1ba', 'Printer', 'Images/Repair/1712179521479.jpeg', '2024-04-03 23:25:21', '2024-04-03 23:25:21');

-- --------------------------------------------------------

--
-- Table structure for table `requirements`
--

CREATE TABLE `requirements` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `workcard_id` int(11) NOT NULL,
  `keepingUnit` varchar(255) NOT NULL,
  `product` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `isToBePaid` tinyint(1) NOT NULL DEFAULT 0,
  `isPaidFor` tinyint(1) NOT NULL DEFAULT 0,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requirements`
--

INSERT INTO `requirements` (`id`, `uuid`, `workcard_id`, `keepingUnit`, `product`, `price`, `isToBePaid`, `isPaidFor`, `createdAt`, `updatedAt`) VALUES
(1, '94c45b2c-536c-4c57-9443-0bd2ef9381a3', 2, 'PRD0005', '8GB DDR4 3200 MHz SO-DIMM', 25.00, 0, 0, '2024-04-04 11:57:42', '2024-04-04 11:57:42');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `method` varchar(255) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `newTotalAmount` decimal(10,2) NOT NULL,
  `paidAmount` decimal(10,2) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `cashier` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `date`, `totalAmount`, `method`, `rate`, `newTotalAmount`, `paidAmount`, `phone`, `cashier`, `createdAt`, `updatedAt`) VALUES
(1, '2024-04-03 22:26:01', 892.00, 'USD Cash', 1.00, 892.00, 900.00, '263784711808', 2, '2024-04-03 22:26:01', '2024-04-03 22:26:01'),
(2, '2024-04-03 22:27:31', 404.00, 'USD Cash', 1.00, 404.00, 410.00, '263713076783', 2, '2024-04-03 22:27:31', '2024-04-03 22:27:31'),
(3, '2024-04-03 23:31:18', 638.00, 'USD Cash', 1.00, 638.00, 650.00, '263713075783', 2, '2024-04-03 23:31:18', '2024-04-03 23:31:18'),
(4, '2024-04-03 23:32:06', 75.00, 'USD Nostro', 1.20, 90.00, 90.00, '263776419969', 2, '2024-04-03 23:32:06', '2024-04-03 23:32:06'),
(5, '2024-04-04 10:00:57', 877.00, 'USD Cash', 1.00, 877.00, 900.00, '263776419969', 2, '2024-04-04 10:00:57', '2024-04-04 10:00:57'),
(6, '2024-04-04 11:56:26', 675.00, 'USD Cash', 1.00, 675.00, 675.00, '263776419969', 2, '2024-04-04 11:56:26', '2024-04-04 11:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `Sessions`
--

CREATE TABLE `Sessions` (
  `sid` varchar(36) NOT NULL,
  `expires` datetime DEFAULT NULL,
  `data` text DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Sessions`
--

INSERT INTO `Sessions` (`sid`, `expires`, `data`, `createdAt`, `updatedAt`) VALUES
('-RQYuwDvCzo0IL9MDjvg45sVJbo2r6Ii', '2024-04-04 22:12:16', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:12:16', '2024-04-03 22:12:16'),
('0oD3Kn0cPGwXj1uc4uYOEVphMkfxEGwt', '2024-04-04 22:13:34', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:13:34', '2024-04-03 22:13:34'),
('0S5KRWHXX_gnapxGOrPMX5nKjcXV8Bsa', '2024-04-04 22:24:33', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:24:33', '2024-04-03 22:24:33'),
('1Nzbt_sTPOxoS6T_LZn_lmqlrU79saiN', '2024-04-05 09:59:22', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 09:59:22', '2024-04-04 09:59:22'),
('28fg-0zDDjJOrfMAeiHp1MNmtyzKDeyS', '2024-04-04 22:16:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:26', '2024-04-03 22:16:26'),
('2X9XGYWqMCwXvJXLEWGCJ6NvjnqN2fOy', '2024-04-05 11:44:07', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:05', '2024-04-04 11:44:07'),
('3zFe0P1XCkb_-SEO-ltOv1gBWjtIfXym', '2024-04-05 09:58:22', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 09:58:23', '2024-04-04 09:58:23'),
('4aUEu-cGLbEUFbcg2kxIz-GIl4cOWRCL', '2024-04-05 11:57:42', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:57:42', '2024-04-04 11:57:42'),
('4IKVTdFkBZtDaqRoEnmlNkAK0mIxel57', '2024-04-04 22:17:48', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:17:48', '2024-04-03 22:17:48'),
('4KaJX9sgsoN5m4R2VbyV1v0q84to88-J', '2024-04-04 22:23:21', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:23:21', '2024-04-03 22:23:21'),
('56alXIUtCKPQdy-G5wa5uG4_01WENw39', '2024-04-04 22:23:33', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:23:33', '2024-04-03 22:23:33'),
('6-E3HhNdBaBAX5SawL2cDAbhaN6mMftb', '2024-04-04 22:33:44', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:33:44', '2024-04-03 22:33:44'),
('6rVZz7xJwrMz-dSDgcSu08IFBIca6aYl', '2024-04-04 22:16:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:26', '2024-04-03 22:16:26'),
('7ak7V8P5JJPjp-8ArEYToUdlvXpgE_03', '2024-04-04 22:16:28', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:28', '2024-04-03 22:16:28'),
('7z_z_byEKDMSXzZJR8wM6ub69mQ8l3Kd', '2024-04-04 22:13:53', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:13:53', '2024-04-03 22:13:53'),
('8F_xDMyNf7KCeHSyC2nV1UYFj5FRonuT', '2024-04-04 21:30:48', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:30:49', '2024-04-03 21:30:49'),
('9erQn4-xXoqOuwQ2BygGNRdQBJvbaYyd', '2024-04-05 11:56:39', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:56:39', '2024-04-04 11:56:39'),
('9fci8ySW6KafSQ903xv2uXnYaO5SFSbG', '2024-04-05 11:24:06', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:24:06', '2024-04-04 11:24:06'),
('9SdkoGB3_Xit_5ALahZgxa7fqcd-NbN5', '2024-04-04 21:24:54', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:24:54', '2024-04-03 21:24:54'),
('9UaBTRDmtjvIIbo342_yBI_cI1C_FG3O', '2024-04-04 22:08:22', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:08:22', '2024-04-03 22:08:22'),
('9WV0qfo1qh7KZdoHGvAZOAxsFXJ-yJ7q', '2024-04-04 22:34:35', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:34:35', '2024-04-03 22:34:35'),
('A1dmLQs3wIE9bE6oqgQb-YM5ZZiqGQ6k', '2024-04-05 11:57:52', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:57:52', '2024-04-04 11:57:52'),
('A8Qc-X3CwR5MK3LETvhSMO2SGdO5Z2sO', '2024-04-05 11:44:05', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:05', '2024-04-04 11:44:05'),
('atYlfRrM6fSaRahNCeAI6w7xowG17s1g', '2024-04-04 22:08:06', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:08:06', '2024-04-03 22:08:06'),
('bcjK6VzIED1NUWnXCtEsSf-MW3zcpjH4', '2024-04-05 12:01:40', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"},\"userId\":\"81a8152a-dc80-442f-803d-375d1fb3a24a\"}', '2024-04-04 11:58:23', '2024-04-04 12:01:40'),
('BHdwQlWs2dDrdM0SxlvovrmlEOl7Y0U0', '2024-04-04 22:24:22', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:24:22', '2024-04-03 22:24:22'),
('BKp1OCxl2lDa3OVlQbJBxE6XyShkPYyE', '2024-04-04 21:25:34', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:25:34', '2024-04-03 21:25:34'),
('bXf3_BlY0q-I3-H7ON3427IYq4DXtN7C', '2024-04-05 11:23:47', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:23:47', '2024-04-04 11:23:47'),
('C09KflcF16ijAhx0KdSf489lBceoHADJ', '2024-04-04 22:22:04', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:22:05', '2024-04-03 22:22:05'),
('cbUUXQ183DFmrlbwq2ZYYHcfvkhuI2Or', '2024-04-05 09:59:18', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 09:59:18', '2024-04-04 09:59:18'),
('cfDD_I8e97mDL_ns0fmjCOIm0dxJ1o1J', '2024-04-04 21:25:16', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:25:16', '2024-04-03 21:25:16'),
('CH3PuppW7W247E4juGyDQDiXmDJsCDFX', '2024-04-05 11:44:27', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:27', '2024-04-04 11:44:27'),
('cknTj6CPMJUqLE7e7PDLvTxEiiqHnpbc', '2024-04-04 23:29:42', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:29:42', '2024-04-03 23:29:42'),
('cRSsTpFF_UT8_Yuzk0i-IqETO9xgSC45', '2024-04-04 22:26:01', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:26:01', '2024-04-03 22:26:01'),
('cvLg5PglsrqYyx-GoNStB16z1mlLUbcw', '2024-04-04 22:16:28', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:28', '2024-04-03 22:16:28'),
('d1ZvH09AwkrStjLROjgmPWodV-XVlzwe', '2024-04-05 11:12:13', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:12:13', '2024-04-04 11:12:13'),
('dh0k52mFRmX4DPB4qejIkRXiyrXGPcyF', '2024-04-04 22:21:29', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:21:29', '2024-04-03 22:21:29'),
('dQ6x7Qm5W9h2-MDufMy2d_rMJrdHHLYj', '2024-04-05 12:01:27', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 12:01:27', '2024-04-04 12:01:27'),
('ebIqiWSvcNY8ukhEElv_DVrQTZ954CFT', '2024-04-05 11:50:53', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:50:53', '2024-04-04 11:50:53'),
('EbIxvbGlNIDEaAzruYZH6p43u8ByDYmM', '2024-04-04 23:32:06', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:32:06', '2024-04-03 23:32:06'),
('eQ3IqPlPGbkYeZt6mSIX42FHH76lUPCI', '2024-04-04 23:29:36', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:29:36', '2024-04-03 23:29:36'),
('eUTggpEEh5wOLK2s4iAroDgYIEQrwrDZ', '2024-04-05 11:49:36', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:49:36', '2024-04-04 11:49:36'),
('EYpAAvfq3o_19n0sGiuCujabDfDv4X8v', '2024-04-04 22:34:55', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:34:55', '2024-04-03 22:34:55'),
('fbYrlTszOyukt3AB3Gh5yfbkal0n3PtW', '2024-04-05 11:22:42', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:22:42', '2024-04-04 11:22:42'),
('FITUsTAtflXZtKdvCan4u7koPGbRM7QG', '2024-04-05 11:51:13', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:51:13', '2024-04-04 11:51:13'),
('fl-EeOQVJF1xiKLdhK9erNba65VJKvQz', '2024-04-05 11:22:17', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:22:17', '2024-04-04 11:22:17'),
('G8MuBfXeNBvO14Z6Ghckmqtv0hgVu_c8', '2024-04-04 21:52:45', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:52:45', '2024-04-03 21:52:45'),
('GbT_x9q3T-I1uWMWVNg5XnhE3Yo0gKth', '2024-04-04 23:36:40', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:36:40', '2024-04-03 23:36:40'),
('gbwlCmsxoVBdQs9TwA70SRJNqfR8_fJS', '2024-04-04 22:17:58', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:17:58', '2024-04-03 22:17:58'),
('gOF9RNiR3MfweVp4OnufLf5RUbiC_BHr', '2024-04-05 11:12:08', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:12:08', '2024-04-04 11:12:08'),
('gXEbW_l2IgFbrbRpb36K2IyrHYok1HLA', '2024-04-05 11:57:01', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:57:01', '2024-04-04 11:57:01'),
('hFC7P4YppfUOvNxRuh7t_xjdVbnYisi7', '2024-04-04 23:32:39', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:32:39', '2024-04-03 23:32:39'),
('HWc9HiTcYXD9qSGg0KM3x61QM1IprKCF', '2024-04-04 21:25:04', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:25:04', '2024-04-03 21:25:04'),
('hYQ3rLQgrkBiO6baM3EYouH7iQYzYDFu', '2024-04-04 22:16:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:26', '2024-04-03 22:16:26'),
('iMOw3E4pnv32fLOMgtFqpHwRU1xGPl2h', '2024-04-04 21:22:23', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:22:23', '2024-04-03 21:22:23'),
('ImsFQkxKrotaN3oRCN-rmUCi8BPDM4c6', '2024-04-05 11:58:23', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:58:23', '2024-04-04 11:58:23'),
('jCULA4oNEI_ZbzdT0i4pQiVdLhLxE0_v', '2024-04-05 11:58:17', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:58:17', '2024-04-04 11:58:17'),
('jqwRuKWVTpjhKXKx5RWXRSwSfwXvFlcs', '2024-04-04 22:16:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:26', '2024-04-03 22:16:26'),
('kfe-_89LJZSS4PJdZbkx9eQLiT_A3pIy', '2024-04-04 22:32:41', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:32:41', '2024-04-03 22:32:41'),
('KLG3WbBxexK3YFq9znMKqkPA7uhIM0UN', '2024-04-04 23:37:04', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"},\"userId\":\"f212ab95-3276-46a4-8661-2069776d9212\"}', '2024-04-03 23:32:48', '2024-04-03 23:37:04'),
('km96u8i21mn2oOH4ls2SP8__V58zKE_q', '2024-04-04 22:16:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:26', '2024-04-03 22:16:26'),
('kNgtbmU5hJqCuEKWBjlb8Q7UjTN_Mc6C', '2024-04-05 11:51:41', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:51:41', '2024-04-04 11:51:41'),
('LcA9dOv1D3zsugK5dR9xBPsGHWxXvTrU', '2024-04-05 11:56:26', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:56:26', '2024-04-04 11:56:26'),
('lLkP3VTBtOzSh5CleNoqgxSWDjK7qvIU', '2024-04-04 22:27:30', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:27:30', '2024-04-03 22:27:30'),
('l_WkNaWOC_yp0npZB9Wby_xRyUnXEwPT', '2024-04-04 21:56:24', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:56:24', '2024-04-03 21:56:24'),
('mDXpc-1It3MIu6TRdel6QJR-gYTCkT7T', '2024-04-05 11:51:36', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:51:36', '2024-04-04 11:51:36'),
('MmyeK7vuutXsTp_muww_soP3p-Fi4GfG', '2024-04-04 21:58:42', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:58:42', '2024-04-03 21:58:42'),
('nn0mGCV-5uLKyCG_hQ9dWFPtcVPdjiYQ', '2024-04-04 22:04:33', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:04:33', '2024-04-03 22:04:33'),
('O0pVjjSMjRY2aJ_akL1YUihlg4eXBPCM', '2024-04-04 23:23:54', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:23:55', '2024-04-03 23:23:55'),
('OojJGN09oWUaHgLzH7QnSfD-B2JiuaX0', '2024-04-04 21:49:44', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:49:44', '2024-04-03 21:49:44'),
('OSJaKz-VTxwzF-GPqfbRT45k4oZFQbts', '2024-04-04 22:03:21', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:03:21', '2024-04-03 22:03:21'),
('p5hVGWKbph4fY-5WZf5MUw-CUGfpJINM', '2024-04-05 10:00:56', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 10:00:57', '2024-04-04 10:00:57'),
('PBt-PUidLhTQsBcmdPNwvbggIF6-3Ccv', '2024-04-04 22:14:29', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:14:29', '2024-04-03 22:14:29'),
('riASWG47Z-zrMJKGayZh_kok5eR_Z8he', '2024-04-04 21:59:00', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:59:00', '2024-04-03 21:59:00'),
('rs3_KPE9CJnhPAWF5UX8p5DyvVibAGgP', '2024-04-04 22:16:28', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:28', '2024-04-03 22:16:28'),
('rysAB6yqsuMsWOjybPo7d4vokXsxKB18', '2024-04-05 11:44:23', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:23', '2024-04-04 11:44:23'),
('S-Cx2bg-pEnXp3sF97Afzm-clwTbKMKR', '2024-04-04 22:32:29', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:32:29', '2024-04-03 22:32:29'),
('S3WSpNeKoDgrXclrNt_6kZLiY3J0J-to', '2024-04-04 21:25:50', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:25:50', '2024-04-03 21:25:50'),
('s8CBZaImTS7hzCxiOboUaVAWWLQhFOSR', '2024-04-05 11:49:09', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:49:10', '2024-04-04 11:49:10'),
('SbPt-0c05dr9SliL7BsWraQZTTcuq8_w', '2024-04-04 22:38:18', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"},\"userId\":\"901e6f9e-d523-4afc-a252-176a00e67628\"}', '2024-04-03 22:34:35', '2024-04-03 22:38:18'),
('TAKuzOorTcMU33csw_NQeu6B1bM4so7K', '2024-04-04 22:23:03', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:23:03', '2024-04-03 22:23:03'),
('TaoB5a05wWPJAA2zsP-ZeX2P4KpLU2dY', '2024-04-04 22:31:43', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:31:43', '2024-04-03 22:31:43'),
('TTmDBm_1MbTIQ5jj4s5py_9ovIf2zMot', '2024-04-04 21:07:51', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:07:51', '2024-04-03 21:07:51'),
('vh3MnxkDXTiICL_Qv8lE2NKowa_HDCa5', '2024-04-04 23:32:47', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:32:47', '2024-04-03 23:32:47'),
('wBvSyAT0JomUFk8jnUxQfXaz2PcB81II', '2024-04-05 11:44:05', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:05', '2024-04-04 11:44:05'),
('WIcusgpQWqnJ7yeFjmuqzMiQM7DO4UJk', '2024-04-04 21:23:38', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:23:39', '2024-04-03 21:23:39'),
('YjjLjN8pGLmv6SKkiRLe5LVew7ma9jRZ', '2024-04-04 21:24:30', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:24:30', '2024-04-03 21:24:30'),
('Z3ffhwkUYodi6OsgcT6wjsBYvfiyBDwJ', '2024-04-04 21:07:31', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 21:07:33', '2024-04-03 21:07:33'),
('z5PLG2T13astyqdLMuL3dDCXBSXJUmJ4', '2024-04-04 22:16:28', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:16:28', '2024-04-03 22:16:28'),
('Z6NwhSHm422gCrFIfNPn2mpxs9snavps', '2024-04-04 23:31:18', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 23:31:18', '2024-04-03 23:31:18'),
('ZEu3gwOGsbrwEHPJuGpNfPCQtboboL8n', '2024-04-05 11:44:29', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-04 11:44:29', '2024-04-04 11:44:29'),
('zYp8T1GB6Ov_TC82NDFUizwdGjl3tHE1', '2024-04-04 22:22:47', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:22:47', '2024-04-03 22:22:47'),
('_fSpfqON33_8ptUdFoVnCR1riDHI6XuE', '2024-04-04 22:22:19', '{\"cookie\":{\"originalMaxAge\":null,\"expires\":null,\"secure\":false,\"httpOnly\":true,\"path\":\"/\"}}', '2024-04-03 22:22:19', '2024-04-03 22:22:19');

-- --------------------------------------------------------

--
-- Table structure for table `sku_id`
--

CREATE TABLE `sku_id` (
  `id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sku_id`
--

INSERT INTO `sku_id` (`id`) VALUES
(1),
(2),
(3),
(4),
(5);

-- --------------------------------------------------------

--
-- Table structure for table `soldItems`
--

CREATE TABLE `soldItems` (
  `id` int(11) NOT NULL,
  `sales_id` int(11) NOT NULL,
  `product` varchar(255) NOT NULL,
  `keepingUnit` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `soldItems`
--

INSERT INTO `soldItems` (`id`, `sales_id`, `product`, `keepingUnit`, `quantity`, `price`, `cost`, `createdAt`, `updatedAt`) VALUES
(1, 1, 'Inspiron 3000 Laptop', 'PRD0003', 1, 650.00, 650.00, '2024-04-03 22:26:01', '2024-04-03 22:26:01'),
(2, 1, '16GB DDR4 3200 MHz ', 'PRD0004', 1, 40.00, 40.00, '2024-04-03 22:26:01', '2024-04-03 22:26:01'),
(3, 1, 'PIXMA G2010', 'PRD0002', 1, 202.00, 202.00, '2024-04-03 22:26:01', '2024-04-03 22:26:01'),
(4, 2, 'PIXMA G2010', 'PRD0002', 2, 202.00, 404.00, '2024-04-03 22:27:31', '2024-04-03 22:27:31'),
(5, 3, 'ThinkCentre Neo 50s Gen 4 (Intel) SFF', 'PRD0001', 1, 598.00, 598.00, '2024-04-03 23:31:18', '2024-04-03 23:31:18'),
(6, 3, '16GB DDR4 3200 MHz ', 'PRD0004', 1, 40.00, 40.00, '2024-04-03 23:31:18', '2024-04-03 23:31:18'),
(7, 4, '8GB DDR4 3200 MHz SO-DIMM', 'PRD0005', 3, 25.00, 75.00, '2024-04-03 23:32:06', '2024-04-03 23:32:06'),
(8, 5, '8GB DDR4 3200 MHz SO-DIMM', 'PRD0005', 1, 25.00, 25.00, '2024-04-04 10:00:57', '2024-04-04 10:00:57'),
(9, 5, 'PIXMA G2010', 'PRD0002', 1, 202.00, 202.00, '2024-04-04 10:00:57', '2024-04-04 10:00:57'),
(10, 5, 'Inspiron 3000 Laptop', 'PRD0003', 1, 650.00, 650.00, '2024-04-04 10:00:57', '2024-04-04 10:00:57'),
(11, 6, 'Inspiron 3000 Laptop', 'PRD0003', 1, 650.00, 650.00, '2024-04-04 11:56:26', '2024-04-04 11:56:26'),
(12, 6, '8GB DDR4 3200 MHz SO-DIMM', 'PRD0005', 1, 25.00, 25.00, '2024-04-04 11:56:26', '2024-04-04 11:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `workshop`
--

CREATE TABLE `workshop` (
  `id` int(11) NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` datetime NOT NULL,
  `cardNo` varchar(255) NOT NULL,
  `diagnosisResults` varchar(255) NOT NULL,
  `otherRequirements` varchar(255) DEFAULT NULL,
  `otherRequirementsUsed` varchar(255) DEFAULT NULL,
  `estimatedTime` varchar(255) NOT NULL,
  `labourCharge` decimal(10,2) NOT NULL,
  `invoice` varchar(255) DEFAULT NULL,
  `jobdone` varchar(255) DEFAULT NULL,
  `partsUsed` varchar(255) DEFAULT NULL,
  `timeTaken` varchar(255) DEFAULT NULL,
  `technician` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workshop`
--

INSERT INTO `workshop` (`id`, `uuid`, `date`, `cardNo`, `diagnosisResults`, `otherRequirements`, `otherRequirementsUsed`, `estimatedTime`, `labourCharge`, `invoice`, `jobdone`, `partsUsed`, `timeTaken`, `technician`, `createdAt`, `updatedAt`) VALUES
(1, '04703902-874d-43cd-86b2-d64b0863fd88', '2024-04-04 11:23:47', 'TWX0001', 'the device needs lcd replacement, and some belts', 'Lcd', NULL, '3', 15.00, NULL, NULL, NULL, NULL, 4, '2024-04-04 11:23:47', '2024-04-04 11:23:47'),
(2, '6a600688-b574-4e9b-b053-eb1e231a4079', '2024-04-04 11:57:42', 'TWX0002', 'wefhjyobpoymlnhfbo', NULL, NULL, '2', 10.00, NULL, NULL, NULL, NULL, 3, '2024-04-04 11:57:42', '2024-04-04 11:57:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`id`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `cardpayments`
--
ALTER TABLE `cardpayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `cardNo` (`cardNo`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `card_id`
--
ALTER TABLE `card_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `collection`
--
ALTER TABLE `collection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customerID` (`customerID`),
  ADD KEY `cardNo` (`cardNo`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customerID` (`customerID`);

--
-- Indexes for table `customer_id`
--
ALTER TABLE `customer_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devicemodel`
--
ALTER TABLE `devicemodel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repairId` (`repairId`),
  ADD KEY `manufactureId` (`manufactureId`);

--
-- Indexes for table `diagnosisFee`
--
ALTER TABLE `diagnosisFee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cardNo` (`cardNo`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `keepingUnit` (`keepingUnit`),
  ADD KEY `catId` (`catId`),
  ADD KEY `makeId` (`makeId`);

--
-- Indexes for table `jobcards`
--
ALTER TABLE `jobcards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialNo` (`serialNo`),
  ADD UNIQUE KEY `cardNo` (`cardNo`),
  ADD KEY `customerID` (`customerID`),
  ADD KEY `catId` (`catId`),
  ADD KEY `makeId` (`makeId`);

--
-- Indexes for table `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repairId` (`repairId`);

--
-- Indexes for table `modelproblem`
--
ALTER TABLE `modelproblem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `repairId` (`repairId`),
  ADD KEY `manufactureId` (`manufactureId`),
  ADD KEY `modelId` (`modelId`);

--
-- Indexes for table `ordercollection`
--
ALTER TABLE `ordercollection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `orderedservices`
--
ALTER TABLE `orderedservices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `problem_id` (`problem_id`);

--
-- Indexes for table `orderpayments`
--
ALTER TABLE `orderpayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `user` (`user`);

--
-- Indexes for table `orderservice`
--
ALTER TABLE `orderservice`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orderId` (`orderId`),
  ADD KEY `modelId` (`modelId`),
  ADD KEY `customerId` (`customerId`);

--
-- Indexes for table `orderserv_id`
--
ALTER TABLE `orderserv_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderswork`
--
ALTER TABLE `orderswork`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderId` (`orderId`),
  ADD KEY `technician` (`technician`);

--
-- Indexes for table `partsrequired`
--
ALTER TABLE `partsrequired`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workorder_id` (`workorder_id`),
  ADD KEY `keepingUnit` (`keepingUnit`);

--
-- Indexes for table `paymentmethod`
--
ALTER TABLE `paymentmethod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repaircategory`
--
ALTER TABLE `repaircategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requirements`
--
ALTER TABLE `requirements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `workcard_id` (`workcard_id`),
  ADD KEY `keepingUnit` (`keepingUnit`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cashier` (`cashier`);

--
-- Indexes for table `Sessions`
--
ALTER TABLE `Sessions`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `sku_id`
--
ALTER TABLE `sku_id`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `soldItems`
--
ALTER TABLE `soldItems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `keepingUnit` (`keepingUnit`);

--
-- Indexes for table `workshop`
--
ALTER TABLE `workshop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cardNo` (`cardNo`),
  ADD KEY `technician` (`technician`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brand`
--
ALTER TABLE `brand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `cardpayments`
--
ALTER TABLE `cardpayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `card_id`
--
ALTER TABLE `card_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `collection`
--
ALTER TABLE `collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_id`
--
ALTER TABLE `customer_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `devicemodel`
--
ALTER TABLE `devicemodel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `diagnosisFee`
--
ALTER TABLE `diagnosisFee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jobcards`
--
ALTER TABLE `jobcards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `manufacturer`
--
ALTER TABLE `manufacturer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `modelproblem`
--
ALTER TABLE `modelproblem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ordercollection`
--
ALTER TABLE `ordercollection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderedservices`
--
ALTER TABLE `orderedservices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderpayments`
--
ALTER TABLE `orderpayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderservice`
--
ALTER TABLE `orderservice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderserv_id`
--
ALTER TABLE `orderserv_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orderswork`
--
ALTER TABLE `orderswork`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `partsrequired`
--
ALTER TABLE `partsrequired`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paymentmethod`
--
ALTER TABLE `paymentmethod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `repaircategory`
--
ALTER TABLE `repaircategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `requirements`
--
ALTER TABLE `requirements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sku_id`
--
ALTER TABLE `sku_id`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `soldItems`
--
ALTER TABLE `soldItems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `workshop`
--
ALTER TABLE `workshop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `brand`
--
ALTER TABLE `brand`
  ADD CONSTRAINT `brand_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cardpayments`
--
ALTER TABLE `cardpayments`
  ADD CONSTRAINT `cardpayments_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `cardpayments_ibfk_2` FOREIGN KEY (`cardNo`) REFERENCES `jobcards` (`cardNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cardpayments_ibfk_3` FOREIGN KEY (`user`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `collection`
--
ALTER TABLE `collection`
  ADD CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customers` (`customerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `collection_ibfk_2` FOREIGN KEY (`cardNo`) REFERENCES `jobcards` (`cardNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `collection_ibfk_3` FOREIGN KEY (`user`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `devicemodel`
--
ALTER TABLE `devicemodel`
  ADD CONSTRAINT `devicemodel_ibfk_1` FOREIGN KEY (`repairId`) REFERENCES `repaircategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `devicemodel_ibfk_2` FOREIGN KEY (`manufactureId`) REFERENCES `manufacturer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `diagnosisFee`
--
ALTER TABLE `diagnosisFee`
  ADD CONSTRAINT `diagnosisFee_ibfk_1` FOREIGN KEY (`cardNo`) REFERENCES `jobcards` (`cardNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diagnosisFee_ibfk_2` FOREIGN KEY (`user`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `inventory`
--
ALTER TABLE `inventory`
  ADD CONSTRAINT `inventory_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inventory_ibfk_2` FOREIGN KEY (`makeId`) REFERENCES `brand` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jobcards`
--
ALTER TABLE `jobcards`
  ADD CONSTRAINT `jobcards_ibfk_1` FOREIGN KEY (`customerID`) REFERENCES `customers` (`customerID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobcards_ibfk_2` FOREIGN KEY (`catId`) REFERENCES `repaircategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jobcards_ibfk_3` FOREIGN KEY (`makeId`) REFERENCES `manufacturer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `manufacturer`
--
ALTER TABLE `manufacturer`
  ADD CONSTRAINT `manufacturer_ibfk_1` FOREIGN KEY (`repairId`) REFERENCES `repaircategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `modelproblem`
--
ALTER TABLE `modelproblem`
  ADD CONSTRAINT `modelproblem_ibfk_1` FOREIGN KEY (`repairId`) REFERENCES `repaircategory` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modelproblem_ibfk_2` FOREIGN KEY (`manufactureId`) REFERENCES `manufacturer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `modelproblem_ibfk_3` FOREIGN KEY (`modelId`) REFERENCES `devicemodel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ordercollection`
--
ALTER TABLE `ordercollection`
  ADD CONSTRAINT `ordercollection_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orderservice` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ordercollection_ibfk_2` FOREIGN KEY (`user`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderedservices`
--
ALTER TABLE `orderedservices`
  ADD CONSTRAINT `orderedservices_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orderservice` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderedservices_ibfk_2` FOREIGN KEY (`problem_id`) REFERENCES `modelproblem` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderpayments`
--
ALTER TABLE `orderpayments`
  ADD CONSTRAINT `orderpayments_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `orderpayments_ibfk_2` FOREIGN KEY (`orderId`) REFERENCES `orderservice` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderpayments_ibfk_3` FOREIGN KEY (`user`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderservice`
--
ALTER TABLE `orderservice`
  ADD CONSTRAINT `orderservice_ibfk_1` FOREIGN KEY (`modelId`) REFERENCES `devicemodel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderservice_ibfk_2` FOREIGN KEY (`customerId`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orderswork`
--
ALTER TABLE `orderswork`
  ADD CONSTRAINT `orderswork_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orderservice` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orderswork_ibfk_2` FOREIGN KEY (`technician`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partsrequired`
--
ALTER TABLE `partsrequired`
  ADD CONSTRAINT `partsrequired_ibfk_1` FOREIGN KEY (`workorder_id`) REFERENCES `orderswork` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `partsrequired_ibfk_2` FOREIGN KEY (`keepingUnit`) REFERENCES `inventory` (`keepingUnit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `requirements`
--
ALTER TABLE `requirements`
  ADD CONSTRAINT `requirements_ibfk_1` FOREIGN KEY (`workcard_id`) REFERENCES `workshop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `requirements_ibfk_2` FOREIGN KEY (`keepingUnit`) REFERENCES `inventory` (`keepingUnit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`cashier`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `soldItems`
--
ALTER TABLE `soldItems`
  ADD CONSTRAINT `soldItems_ibfk_1` FOREIGN KEY (`sales_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `soldItems_ibfk_2` FOREIGN KEY (`keepingUnit`) REFERENCES `inventory` (`keepingUnit`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workshop`
--
ALTER TABLE `workshop`
  ADD CONSTRAINT `workshop_ibfk_1` FOREIGN KEY (`cardNo`) REFERENCES `jobcards` (`cardNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `workshop_ibfk_2` FOREIGN KEY (`technician`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
